# Catatan Kontinuitas — Alur M01a–M06 (Selang-seling Host Chiasa & Yutaka)

Status Alur: **M01a–M05b Selesai Penuh (ACC) · M06 Host Chiasa Terpasang — Menunggu ACC Grand Bab M06 Host Chiasa**

## 1. Status Bagian
| Bagian | Event & Cakupan | Status | File Target |
|---|---|---|---|
| Bagian 1–2 | `C01` (Host Chiasa, M01a) | **ACC** | `game/kk_flow.rpy` |
| Bagian 3–4 | `Y01` (Host Yutaka, M01a) | **ACC** | `game/kk_flow.rpy` |
| Bagian 5–6 | `Mo01` (Host Chiasa & Yutaka, M01b) | **ACC** | `game/kk_spring.rpy` |
| Bagian 8–10 | `C02`, `K01`, `N01` (Host Chiasa, M01a) | **ACC** | `game/kk_chiasa_host.rpy`, `game/kk_koita_y1.rpy`, `game/kk_scenes.rpy` |
| Bagian 11–14 | `Y02`, `Y03`, `K01`, `N01` (Host Yutaka, M01a) | **ACC** | `game/kk_yutaka_host.rpy`, `game/kk_yutaka_route.rpy`, `game/kk_koita_y1.rpy`, `game/kk_scenes.rpy` |
| Grand Bab M01b (Chiasa) | `H01` + `S01` + `Mi01` — Host Chiasa | **ACC** | `game/kk_harumi.rpy`, `game/kk_spring.rpy`, `game/kk_scenes.rpy` |
| Grand Bab M01b (Yutaka) | `H01` + `S01` + `Mi01` — Host Yutaka | **ACC** | `game/kk_harumi.rpy`, `game/kk_spring.rpy`, `game/kk_scenes.rpy` |
| Grand Bab M02 (Chiasa) | `K02` + `Mo02` + `S02` + `N02` + `Mi02` — Host Chiasa | **ACC** | `game/kk_ryokan.rpy`, `game/kk_spring.rpy` |
| Grand Bab M02 (Yutaka) | `K02` + `Mo02` + `S02` + `N02` + `Mi02` — Host Yutaka | **ACC** | `game/kk_ryokan.rpy`, `game/kk_spring.rpy` |
| Grand Bab M03 (Chiasa) | `Mo03` + `H02` + `S03` + `N03` — Host Chiasa | **ACC** | `game/kk_moeka.rpy`, `game/kk_harumi_family.rpy`, `game/kk_shiori_early.rpy`, `game/kk_scenes.rpy` |
| Grand Bab M03 (Yutaka) | `Mo03` + `H02` + `S03` + `N03` — Host Yutaka | **ACC** | `game/kk_moeka.rpy`, `game/kk_harumi_family.rpy`, `game/kk_shiori_early.rpy`, `game/kk_scenes.rpy` |
| Grand Bab M04 (Chiasa) | `C03` + `K03` + `H03` + `Mi03` — Host Chiasa | **ACC** | `game/kk_chiasa_host.rpy`, `game/kk_koita_y1.rpy`, `game/kk_harumi.rpy`, `game/kk_scenes.rpy` |
| Grand Bab M04 (Yutaka) | `K03` + `Y04` + `H03` + `Mi03` — Host Yutaka | **ACC** | `game/kk_koita_y1.rpy`, `game/kk_yutaka_route.rpy`, `game/kk_harumi.rpy`, `game/kk_scenes.rpy` |
| Grand Bab M05a (Chiasa) | `C04` + `K04` + `N04` + `Mi04` — Host Chiasa | **ACC** | `game/kk_chiasa_host.rpy`, `game/kk_koita_route.rpy`, `game/kk_life_events.rpy`, `game/kk_miyuki_early.rpy` |
| Grand Bab M05a (Yutaka) | `K04` + `Y05` + `N04` + `Mi04` — Host Yutaka | **ACC** | `game/kk_koita_route.rpy`, `game/kk_yutaka_host.rpy`, `game/kk_life_events.rpy`, `game/kk_miyuki_early.rpy` |
| Grand Bab M05b (Chiasa) | `K05` + `Mo04` + `H04` + `S04` + `Mi05` — Host Chiasa | **ACC** | `game/kk_koita_route.rpy`, `game/kk_moeka.rpy`, `game/kk_harumi_route.rpy`, `game/kk_shiori_route.rpy`, `game/kk_vila.rpy` |
| Grand Bab M05b (Yutaka) | `K05` + `Mo04` + `H04` + `S04` + `Mi05` — Host Yutaka | **ACC** | `game/kk_koita_route.rpy`, `game/kk_moeka.rpy`, `game/kk_harumi_route.rpy`, `game/kk_shiori_route.rpy`, `game/kk_vila.rpy` |
| Grand Bab M06 (Chiasa) | `K06` + `Mo05` + `H05` + `N05` + `Mi06` — Host Chiasa | **Terpasang — Menunggu ACC Grand Bab M06 Chiasa** | `game/kk_koita_y1.rpy`, `game/kk_moeka.rpy`, `game/kk_harumi_family.rpy`, `game/kk_nagisa_early.rpy`, `game/kk_miyuki_daily.rpy` |
| Berikutnya | Grand Bab M06 — Host Yutaka (`K06`, `Mo05`, `H05`, `N05`, `Mi06`) | Menunggu ACC M06 Chiasa | `game/kk_koita_y1.rpy`, `game/kk_moeka.rpy`, `game/kk_harumi_family.rpy`, `game/kk_nagisa_early.rpy`, `game/kk_miyuki_daily.rpy` |

## Aturan Panggilan & SOP Permanen (Terkunci oleh User)
- **Acuan Utama Panggilan:** Wajib mengikuti matriks resmi di [Panggilan_Antarkarakter.md](../../../docs/Panggilan_Antarkarakter.md) (NPC wajib mengikuti tahap perkembangan di tabel; panggilan dari pemain boleh sama atau bervariasi secara natural sesuai situasi/pilihan).
- **Ringkasan Tahap Awal (M01a–M02):**
  - **Koita →** `Yutaka`, `Chi-chan`, `Nagisa-chan`, `Miyuki-senpai`, `Harumi-san`, `Moeka-chan`, `Saionji-san`
  - **Yutaka →** `Koita`, `Chiasa`, `Nagisa`, `Tachibana-senpai`, `Kujo-san`, `Kohinata`, `Saionji-san`
  - **Chiasa →** `Ko-nii` (`Koita` hanya jika sengaja menjauh), `Yutaka-kun`, `Nagisa-senpai`, `Tachibana-senpai`, `Kujo-senpai`, `Moemoe-senpai`, `Saionji-senpai`
  - **Nagisa →** `Ko-kun`, `Yutaka`, `Chiasa`, `Miyuki-senpai`, `Harumi-chan`, `Kohinata-san`, `Saionji-san`
  - **Miyuki →** `Koita-kun`, `Yutaka-kun`, `Chiasa-chan`, `Nagisa-chan`, `Harumi-san`, `Moeka-chan`, `Saionji-san`
  - **Harumi →** `Amamiya-kun`, `Kisaragi-kun`, `Amamiya-san`, `Nagisa`, `Tachibana-senpai`, `Kohinata-san`, `Saionji-san`
  - **Moeka →** `Kocchi`, `Yutayuta`, `Chimian`, `Nacchan`, `Miyumiyu-senpai`, `Hahamama`, `Saionji-san`
  - **Shiori →** `Amamiya-san`, `Kisaragi-san`, `Amamiya-san` (Chiasa), `Sakurajima-san`, `Tachibana-senpai`, `Kujo-san`, `Kohinata-san`
- **Dislokasi Identitas pada Panggilan Khusus:** Buat pemain sesekali merasa aneh/ganjil saat dipanggil dengan julukan khusus (`Chimian`, `Yutayuta`, `Chi-chan`, `Chiasa-chan`, dsb.) karena tubuh ini memang bukan tubuh asli pemain.
- **Fleksibilitas Moral Pemain:** Jangan memaksakan satu suara moral yang seragam (seolah pemain selalu jijik atau selalu antusias terhadap misi NTR). Biarkan tiap pilihan dan reaksi mencerminkan spektrum sikap yang berbeda—bisa tidak nyaman/terpaksa/tertekan, pragmatis/dingin, santai, atau malah bersemangat—sesuai arah pilihannya.
- **Perbedaan Reaksi Host Yutaka vs Host Chiasa:** Meskipun pemain di dalamnya sama, Yutaka dan Chiasa memiliki tubuh, posisi sosial, dan hubungan yang berbeda, sehingga reaksi, gaya bicara, dan detail pengamatan mereka pada situasi yang sama **harus terasa berbeda**, tidak sekadar mengulang teks yang sama dengan nama diganti.
- **Pengetahuan Pemain soal Manga Terbatas (Tidak Serba Tahu):** Pemain bukan pembaca fanatik yang hafal seluruh isi manga—banyak hal, latar belakang, rahasia, dan alur cerita yang **tidak ia ketahui**. Jangan membuat narasi POV seolah pemain hafal profil wiki atau masa depan tokoh.
- **Teks Pilihan (`choice`) Anti-Spoiler:** Boleh disesuaikan agar lebih alami (dialog sebagai dialog, tindakan tetap tindakan) selama inti dan urutan opsi tetap sama, dan **jangan pernah membocorkan hasil/efek** di dalam teks pilihan.
- **Jangan sering mengulang nama jurusan dalam dialog:** Di percakapan alami antar teman, cukup sebut "kelasmu", "kelas pagi tadi", "dosenmu", dsb.—jangan menyebut nama jurusan berulang kali kecuali memang benar-benar perlu secara konteks.
- **SOP Wajib Sebelum Menulis:** Selalu baca dulu `docs/Panggilan_Antarkarakter.md`, file prompt terkait di `docs/Gemini_Prompts/adegan/...`, profil karakter di `Karakter/...`, dan cerita sebelumnya agar detail fisik, panggilan, dan kontinuitas tidak pernah meleset.
- **M06 — Host Chiasa & Yutaka (`K06 → Mo05 → H05 → N05 → Mi06`)**:
  - `K06` (`game/kk_koita_y1.rpy`): Foto bersama di Kafe Komorebi. Kedua host sudah lengkap dengan dinamika posisi di depan papan menu (A: fotografer dari luar bingkai; B: masuk tengah mengacak formasi, Koita zoom-in sekali pada posisi host; C: minta tolong pelayan kafe dan berdiri di ujung dekat Harumi).
  - `Mo05` (`game/kk_moeka.rpy`): Kabar dari rumah (telepon Ibu/Aya) di Kantin Pusat. Host Chiasa lewat obrolan kain tugas desain sesama Fakultas Seni; Host Yutaka lewat obrolan "pendapat orang awam" sesama angkatan. Membuka tekanan ekonomi keluarga Moeka (ayah sakit kronis, ibu 2 kerjaan, 3 adik, syarat beasiswa).
  - `H05` (`game/kk_harumi_family.rpy`): Kelompok belajar di Kafe Komorebi yang bubar. Harumi jujur belum ingin obrolan selesai (A: bantu bereskan cangkir & teh; B: rencana pascasarjana/profesor dan lepas dari sekadar ukuran orang tua; C: pancing rahasia pribadi, Harumi pasang batas tenang tapi tetap lanjut mengobrol).
  - `N05` (`game/kk_nagisa_early.rpy`): Foto berempat di Studio Arsitektur. Membuka cerita boneka kelinci `Koko` hadiah festival dari Koita (A: Nagisa lembut lalu malu & alihkan ke harga tiket; B: goda Koko lusuh, Nagisa refleks lindungi foto lalu tertawa sendiri; C: diam tenang sambil mengenang masa kecil).
  - `Mi06` (`game/kk_miyuki_daily.rpy`): Rencana pediatri di depan papan pajangan gambar anak-anak Gedung Kedokteran (A: dukung & dengar lebih jauh; B: anggap terlalu sederhana, Miyuki dingin & ganti topik; C: tanya apakah Koita sudah tahu, senyum Miyuki menipis).
- **M07 — Host Chiasa & Yutaka (`Mo06 → H06 → S05 → N06 → Mi07`)**:
  - Memperkenalkan 5 NPC rival/eksternal utama untuk kedua host secara lengkap dan seimbang:
  - `Mo06` (`game/kk_moeka.rpy`): **Kuga Renji** (fotografer fashion freelance, 31 tahun) menawarkan sesi foto modeling berbayar besar di Kantin Pusat tapi mengaburkan detail/hak foto (A: dukung; B: halangi & tunjukkan celah kontrak; C: ikut menemani sehingga nada Kuga berubah dingin).
  - `H06` (`game/kk_harumi_route.rpy`): **Ogawa Masato** (kandidat doktor lab kimia, 29 tahun) memuji data katalis Harumi di Perpustakaan Pusat dan menawarkan "bimbingan khusus" di luar jam lab sambil menghindari pertanyaan soal Prof. Mizuhara (A: dukung; B: soroti ketidaksinkronan jawabannya; C: peringatkan terang-terangan & Harumi minta diajarkan cara menilai tanda bahayanya sendiri).
  - `S05` (`game/kk_shiori_route.rpy`): **Tojo Akihiro** (pewaris Tojo Group, 24 tahun) mendekati Shiori di pesta Klub Catur dengan tekanan sosial kerumunan (A: lindungi/buka celah bagi Shiori menutup percakapan; B: mundur, Shiori mencatat diamnya pemain; C: manfaatkan untuk relasi pribadi, ditegur dingin oleh Shiori).
  - `N06` (`game/kk_life_events.rpy`): **Mochizuki Yuuto** (teman sekelas Arsitektur, pemalu & tulus) membantu Nagisa menahan maket di Studio Arsitektur; kondisi `if "N03" in kk_missed:` terjaga di kedua host (A: beri ruang; B: ambil alih tugas Yuuto; C: akui ingin dimintai tolong, Yuuto menyingkir halus & Nagisa tersipu).
  - `Mi07` (`game/kk_family.rpy`): **Hayase Takeru** (residen bedah, 26 tahun, calon omiai pilihan orang tua) muncul singkat di kafe lobi RS Tachibana sebelum Miyuki menunjukkan amplop undangan makan malam resmi keluarga (A: dengar tawarannya dulu; B: minta beri ruang, Miyuki jelaskan orang tuanya justru makin mempercepat bila ada penolakan dari luar; C: jujur bahwa ia berhak menolak tanpa dicap tak tahu terima kasih).
- **Gaya Naskah Natural & Anti-AI:** Hindari kalimat penutup bergaya esai/kesimpulan moral di akhir cabang (`"bukan X, melainkan Y"`, `"tanda bahwa..."`), kurangi em-dash (`—`) yang berlebihan, dan biarkan dialog mengalir seperti obrolan mahasiswa sungguhan dengan jeda, reaksi pendek, serta gerak fisik yang menunjukkan emosi tanpa perlu diceramahi narator.
