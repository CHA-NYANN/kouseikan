# Catatan Kontinuitas — Alur M01a–M09 (Selang-seling Host Chiasa & Yutaka)

Status Alur: **M01a–M08 Selesai Penuh (ACC) · M09 Host Chiasa Terpasang — Menunggu ACC Grand Bab M09 Host Chiasa**

## 1. Status Bagian
| Bagian | Event & Cakupan | Status | File Target |
|---|---|---|---|
| Bagian 1–2 | `C01` (Host Chiasa, M01a) | **ACC** | `game/kk_flow.rpy` |
| Bagian 3–4 | `Y01` (Host Yutaka, M01a) | **ACC** | `game/kk_flow.rpy` |
| Bagian 5–6 | `Mo01` (Host Chiasa & Yutaka, M01b) | **ACC** | `game/kk_spring.rpy` |
| Bagian 8–10 | `C02`, `K01`, `N01` (Host Chiasa, M01a) | **ACC** | `game/kk_chiasa_host.rpy`, `game/kk_koita_y1.rpy`, `game/kk_scenes.rpy` |
| Bagian 11–14 | `Y02`, `Y03`, `K01`, `N01` (Host Yutaka, M01a) | **ACC** | `game/kk_yutaka_host.rpy`, `game/kk_yutaka_route.rpy`, `game/kk_koita_y1.rpy`, `game/kk_scenes.rpy` |
| Grand Bab M01b (Chiasa) | `H01` + `S01` + `Mi01` — Host Chiasa | **ACC** | `game/kk_harumi.rpy`, `game/kk_spring.rpy`, `game/kk_scenes.rpy` |
| Grand Bab M01b (Yutaka) | `H01` + `S01` + `Mi01` — Host Yutaka | **ACC** | `game/kk_harumi.rpy`, `game/kk_spring.rpy`, `game/kk_scenes.rpy` |
| Grand Bab M02 (Chiasa) | `K02` + `Mo02` + `S02` + `N02` + `Mi02` — Host Chiasa | **ACC** | `game/kk_ryokan.rpy`, `game/kk_spring.rpy` |
| Grand Bab M02 (Yutaka) | `K02` + `Mo02` + `S02` + `N02` + `Mi02` — Host Yutaka | **ACC** | `game/kk_ryokan.rpy`, `game/kk_spring.rpy` |
| Grand Bab M03 (Chiasa) | `Mo03` + `H02` + `S03` + `N03` — Host Chiasa | **ACC** | `game/kk_moeka.rpy`, `game/kk_harumi_family.rpy`, `game/kk_shiori_early.rpy`, `game/kk_scenes.rpy` |
| Grand Bab M03 (Yutaka) | `Mo03` + `H02` + `S03` + `N03` — Host Yutaka | **ACC** | `game/kk_moeka.rpy`, `game/kk_harumi_family.rpy`, `game/kk_shiori_early.rpy`, `game/kk_scenes.rpy` |
| Grand Bab M04 (Chiasa) | `C03` + `K03` + `H03` + `Mi03` — Host Chiasa | **ACC** | `game/kk_chiasa_host.rpy`, `game/kk_koita_y1.rpy`, `game/kk_harumi.rpy`, `game/kk_scenes.rpy` |
| Grand Bab M04 (Yutaka) | `K03` + `Y04` + `H03` + `Mi03` — Host Yutaka | **ACC** | `game/kk_koita_y1.rpy`, `game/kk_yutaka_route.rpy`, `game/kk_harumi.rpy`, `game/kk_scenes.rpy` |
| Grand Bab M05a (Chiasa) | `C04` + `K04` + `N04` + `Mi04` — Host Chiasa | **ACC** | `game/kk_chiasa_host.rpy`, `game/kk_koita_route.rpy`, `game/kk_life_events.rpy`, `game/kk_miyuki_early.rpy` |
| Grand Bab M05a (Yutaka) | `K04` + `Y05` + `N04` + `Mi04` — Host Yutaka | **ACC** | `game/kk_koita_route.rpy`, `game/kk_yutaka_host.rpy`, `game/kk_life_events.rpy`, `game/kk_miyuki_early.rpy` |
| Grand Bab M05b (Chiasa) | `K05` + `Mo04` + `H04` + `S04` + `Mi05` — Host Chiasa | **ACC** | `game/kk_koita_route.rpy`, `game/kk_moeka.rpy`, `game/kk_harumi_route.rpy`, `game/kk_shiori_route.rpy`, `game/kk_vila.rpy` |
| Grand Bab M05b (Yutaka) | `K05` + `Mo04` + `H04` + `S04` + `Mi05` — Host Yutaka | **ACC** | `game/kk_koita_route.rpy`, `game/kk_moeka.rpy`, `game/kk_harumi_route.rpy`, `game/kk_shiori_route.rpy`, `game/kk_vila.rpy` |
| Grand Bab M06 (Chiasa & Yutaka) | `K06` + `Mo05` + `H05` + `N05` + `Mi06` | **ACC** | `game/kk_koita_y1.rpy`, `game/kk_moeka.rpy`, `game/kk_harumi_family.rpy`, `game/kk_nagisa_early.rpy`, `game/kk_miyuki_daily.rpy` |
| Grand Bab M07 (Chiasa & Yutaka) | `Mo06` + `H06` + `S05` + `N06` + `Mi07` | **ACC** | `game/kk_moeka.rpy`, `game/kk_harumi_route.rpy`, `game/kk_shiori_route.rpy`, `game/kk_life_events.rpy`, `game/kk_family.rpy` |
| Grand Bab M08 (Chiasa & Yutaka) | `C05/Y06` + `K07` + `Mo07` + `S06` + `Mi08` | **ACC** | `game/kk_art.rpy`, `game/kk_yutaka_route.rpy`, `game/kk_main_extra.rpy`, `game/kk_cleanup_main.rpy`, `game/kk_shiori_early.rpy`, `game/kk_miyuki_early.rpy` |
| Grand Bab M09 (Chiasa) | `C06` + `K08` + `Mo08` + `H07` + `S07` + `N07` + `Mi09` — Host Chiasa | **Terpasang — Menunggu ACC Grand Bab M09 Chiasa** | `game/kk_chiasa_route.rpy`, `game/kk_main_extra.rpy`, `game/kk_moeka.rpy`, `game/kk_harumi_route.rpy`, `game/kk_saionji.rpy`, `game/kk_nagisa_early.rpy`, `game/kk_family.rpy` |
| Berikutnya | Grand Bab M09 — Host Yutaka (`K08`, `Y07`, `Mo08`, `H07`, `S07`, `N07`, `Mi09`) | Menunggu ACC M09 Chiasa | `game/kk_main_extra.rpy`, `game/kk_yutaka_route.rpy`, `game/kk_moeka.rpy`, `game/kk_harumi_route.rpy`, `game/kk_saionji.rpy`, `game/kk_nagisa_early.rpy`, `game/kk_family.rpy` |

## Aturan Panggilan & SOP Permanen (Terkunci oleh User)
- **Acuan Utama Panggilan:** Wajib mengikuti matriks resmi di [Panggilan_Antarkarakter.md](../../../docs/Panggilan_Antarkarakter.md) (NPC wajib mengikuti tahap perkembangan di tabel; panggilan dari pemain boleh sama atau bervariasi secara natural sesuai situasi/pilihan).
- **Ringkasan Tahap Awal (M01a–M02):**
  - **Koita →** `Yutaka`, `Chi-chan`, `Nagisa-chan`, `Miyuki-senpai`, `Harumi-san`, `Moeka-chan`, `Saionji-san`
  - **Yutaka →** `Koita`, `Chiasa`, `Nagisa`, `Tachibana-senpai`, `Kujo-san`, `Kohinata`, `Saionji-san`
  - **Chiasa →** `Ko-nii` (`Koita` hanya jika sengaja menjauh), `Yutaka-kun`, `Nagisa-senpai`, `Tachibana-senpai`, `Kujo-senpai`, `Moemoe-senpai`, `Saionji-senpai`
  - **Nagisa →** `Ko-kun`, `Yutaka`, `Chiasa`, `Miyuki-senpai`, `Harumi-chan`, `Kohinata-san`, `Saionji-san`
  - **Miyuki →** `Koita-kun`, `Yutaka-kun`, `Chiasa-chan`, `Nagisa-chan`, `Harumi-san`, `Moeka-chan`, `Saionji-san`
  - **Harumi →** `Amamiya-kun`, `Kisaragi-kun`, `Amamiya-san`, `Nagisa`, `Tachibana-senpai`, `Kohinata-san`, `Saionji-san`
  - **Moeka →** `Kocchi`, `Yutayuta`, `Chimian`, `Nacchan`, `Miyumiyu-senpai`, `Hahamama`, `Saionji-san`
  - **Shiori →** `Amamiya-san`, `Kisaragi-san`, `Amamiya-san` (Chiasa), `Sakurajima-san`, `Tachibana-senpai`, `Kujo-san`, `Kohinata-san`
- **Dislokasi Identitas pada Panggilan Khusus:** Buat pemain sesekali merasa aneh/ganjil saat dipanggil dengan julukan khusus (`Chimian`, `Yutayuta`, `Chi-chan`, `Chiasa-chan`, dsb.) karena tubuh ini memang bukan tubuh asli pemain.
- **Fleksibilitas Moral Pemain:** Jangan memaksakan satu suara moral yang seragam (seolah pemain selalu jijik atau selalu antusias terhadap misi NTR). Biarkan tiap pilihan dan reaksi mencerminkan spektrum sikap yang berbeda—bisa tidak nyaman/terpaksa/tertekan, pragmatis/dingin, santai, atau malah bersemangat—sesuai arah pilihannya.
- **Perbedaan Reaksi Host Yutaka vs Host Chiasa:** Meskipun pemain di dalamnya sama, Yutaka dan Chiasa memiliki tubuh, posisi sosial, dan hubungan yang berbeda, sehingga reaksi, gaya bicara, dan detail pengamatan mereka pada situasi yang sama **harus terasa berbeda**, tidak sekadar mengulang teks yang sama dengan nama diganti.
- **Pengetahuan Pemain soal Manga Terbatas (Tidak Serba Tahu):** Pemain bukan pembaca fanatik yang hafal seluruh isi manga—banyak hal, latar belakang, rahasia, dan alur cerita yang **tidak ia ketahui**. Jangan membuat narasi POV seolah pemain hafal profil wiki atau masa depan tokoh.
- **Teks Pilihan (`choice`) Anti-Spoiler:** Boleh disesuaikan agar lebih alami (dialog sebagai dialog, tindakan tetap tindakan) selama inti dan urutan opsi tetap sama, dan **jangan pernah membocorkan hasil/efek** di dalam teks pilihan.
- **Jangan sering mengulang nama jurusan dalam dialog:** Di percakapan alami antar teman, cukup sebut "kelasmu", "kelas pagi tadi", "dosenmu", dsb.—jangan menyebut nama jurusan berulang kali kecuali memang benar-benar perlu secara konteks.
- **SOP Wajib Sebelum Menulis:** Selalu baca dulu `docs/Panggilan_Antarkarakter.md`, file prompt terkait di `docs/Gemini_Prompts/adegan/...`, profil karakter di `Karakter/...`, dan cerita sebelumnya agar detail fisik, panggilan, dan kontinuitas tidak pernah meleset.
- **M06 — Host Chiasa & Yutaka (`K06 → Mo05 → H05 → N05 → Mi06`)**:
  - `K06` (`game/kk_koita_y1.rpy`): Foto bersama di Kafe Komorebi. Kedua host sudah lengkap dengan dinamika posisi di depan papan menu (A: fotografer dari luar bingkai; B: masuk tengah mengacak formasi, Koita zoom-in sekali pada posisi host; C: minta tolong pelayan kafe dan berdiri di ujung dekat Harumi).
  - `Mo05` (`game/kk_moeka.rpy`): Kabar dari rumah (telepon Ibu/Aya) di Kantin Pusat. Host Chiasa lewat obrolan kain tugas desain sesama Fakultas Seni; Host Yutaka lewat obrolan "pendapat orang awam" sesama angkatan. Membuka tekanan ekonomi keluarga Moeka (ayah sakit kronis, ibu 2 kerjaan, 3 adik, syarat beasiswa).
  - `H05` (`game/kk_harumi_family.rpy`): Kelompok belajar di Kafe Komorebi yang bubar. Harumi jujur belum ingin obrolan selesai (A: bantu bereskan cangkir & teh; B: rencana pascasarjana/profesor dan lepas dari sekadar ukuran orang tua; C: pancing rahasia pribadi, Harumi pasang batas tenang tapi tetap lanjut mengobrol).
  - `N05` (`game/kk_nagisa_early.rpy`): Foto berempat di Studio Arsitektur. Membuka cerita boneka kelinci `Koko` hadiah festival dari Koita (A: Nagisa lembut lalu malu & alihkan ke harga tiket; B: goda Koko lusuh, Nagisa refleks lindungi foto lalu tertawa sendiri; C: diam tenang sambil mengenang masa kecil).
  - `Mi06` (`game/kk_miyuki_daily.rpy`): Rencana pediatri di depan papan pajangan gambar anak-anak Gedung Kedokteran (A: dukung & dengar lebih jauh; B: anggap terlalu sederhana, Miyuki dingin & ganti topik; C: tanya apakah Koita sudah tahu, senyum Miyuki menipis).
- **M07 — Host Chiasa & Yutaka (`Mo06 → H06 → S05 → N06 → Mi07`)**:
  - Memperkenalkan 5 NPC rival/eksternal utama untuk kedua host secara lengkap dan seimbang:
  - `Mo06` (`game/kk_moeka.rpy`): **Kuga Renji** (fotografer fashion freelance, 31 tahun) menawarkan sesi foto modeling berbayar besar di Kantin Pusat tapi mengaburkan detail/hak foto (A: dukung; B: halangi & tunjukkan celah kontrak; C: ikut menemani sehingga nada Kuga berubah dingin).
  - `H06` (`game/kk_harumi_route.rpy`): **Ogawa Masato** (kandidat doktor lab kimia, 29 tahun) memuji data katalis Harumi di Perpustakaan Pusat dan menawarkan "bimbingan khusus" di luar jam lab sambil menghindari pertanyaan soal Prof. Mizuhara (A: dukung; B: soroti ketidaksinkronan jawabannya; C: peringatkan terang-terangan & Harumi minta diajarkan cara menilai tanda bahayanya sendiri).
  - `S05` (`game/kk_shiori_route.rpy`): **Tojo Akihiro** (pewaris Tojo Group, 24 tahun) mendekati Shiori di pesta Klub Catur dengan tekanan sosial kerumunan (A: lindungi/buka celah bagi Shiori menutup percakapan; B: mundur, Shiori mencatat diamnya pemain; C: manfaatkan untuk relasi pribadi, ditegur dingin oleh Shiori).
  - `N06` (`game/kk_life_events.rpy`): **Mochizuki Yuuto** (teman sekelas Arsitektur, pemalu & tulus) membantu Nagisa menahan maket di Studio Arsitektur; kondisi `if "N03" in kk_missed:` terjaga di kedua host (A: beri ruang; B: ambil alih tugas Yuuto; C: akui ingin dimintai tolong, Yuuto menyingkir halus & Nagisa tersipu).
  - `Mi07` (`game/kk_family.rpy`): **Hayase Takeru** (residen bedah, 26 tahun, calon omiai pilihan orang tua) muncul singkat di kafe lobi RS Tachibana sebelum Miyuki menunjukkan amplop undangan makan malam resmi keluarga (A: dengar tawarannya dulu; B: minta beri ruang, Miyuki jelaskan orang tuanya justru makin mempercepat bila ada penolakan dari luar; C: jujur bahwa ia berhak menolak tanpa dicap tak tahu terima kasih).
- **M08 — Host Chiasa & Yutaka (`C05/Y06`, `K07`, `Mo07`, `S06`, `Mi08`)**:
  - `C05` (`game/kk_art.rpy`): Eksklusif Chiasa — Higashiyama Mio menelepon menawarkan proyek sampul jilid baru novel strategi (A: tolak halus, royalti lama aman; B: terima & mulai latihan garis dasar; C: minta waktu & hubungi Haruka untuk belajar dari awal). Catatan: di `C01-A` (`kk_flow.rpy`), adegan tes gambar langsung dihapus agar pemain tidak langsung sadar kehilangan skill gambar di menit pertama bangun.
  - `Y06` (`game/kk_yutaka_route.rpy`): Eksklusif Yutaka (Malam, `slot == 3`) — Nakamura Daichi datang menawar kabar soal Moeka (dilihat keluar studio komersial bareng fotografer) & Shiori (rumor pihak Tojo) dengan bayaran traktiran ramen (A: traktir ramen; B: tolak; C: tukar info, Daichi mulai curiga pada perubahan Yutaka).
  - `K07` (`game/kk_main_extra.rpy`): Bazar Sastra — Matsuda Takumi memajang esai `"Tokoh Utama yang Tidak Pernah Memilih"` (A: dukung Matsuda & jadi sekutu; B: kritik di depan umum & jadi musuh; C: bela Koita).
  - `Mo07` (`game/kk_cleanup_main.rpy`): Peragaan busana pertama Moeka (A: nonton dari barisan depan; B: bantu di backstage & pegang tangan sebentar; C: absen).
  - `S06` (`game/kk_shiori_early.rpy`): Turnamen terbuka Klub Catur (A: tonton sampai akhir & bahas langkah kuda; B: ikut daftar bertanding langsung lawan Shiori; C: lewat saja).
  - `Mi08` (`game/kk_miyuki_early.rpy`, Sore/Malam `slot in (2,3)`): Kartu kontak konselor Sato Kyoko dari Sena (A: dukung konsultasi & simpan nomor; B: tolak/anggap cuma capek; C: alihkan ke jadwal praktik).
- **M09 — Host Chiasa (`C06 → K08 → Mo08 → H07 → S07 → N07 → Mi09`)**:
  - `C06` (`game/kk_chiasa_route.rpy`, `hari_n in (24,25)` & `slot == 3`): Malam Natal di Rumah Amamiya saat Daisuke & Yoshie di luar kota (A: makan malam sup krim & kue stroberi berdua dengan Koita; B: undang salah satu heroine ke ruang tengah, Koita menepi ke lantai atas; C: keluar ke rumah Sakurajima menemui Nagisa tanpa membawa nama Koita; D: istirahat sendiri di kamar lantai dua).
  - `K08` (`game/kk_main_extra.rpy`): Kebetulan Natal di pelataran Gedung Sastra saat salah satu gadis menunggu Koita di bawah tiang lampu (A: intersep lewat telepon minta Koita ke gerbang timur; B: potong jalur dan ajak bicara gadis itu lebih dulu ke arah stasiun; C: biarkan mereka bertemu; D: masuk ke tengah mereka dan ikut makan/minum bertiga).
  - `Mo08` (`game/kk_moeka.rpy`): Kantin Pusat menjelang Moeka pulang ke kota satelit dengan tiga kantong hadiah untuk Ren, Sora, dan Hinata serta pita bintang lipatan sendiri (A: ikut naik kereta sejam ke rumahnya dan bantu bawa barang; B: titip tiga pak biskuit Natal & buku sketsa kecil; C: tidak terlibat, Moeka kirim foto adik-adiknya dari balik kamera).
  - `H07` (`game/kk_harumi_route.rpy`): Perpustakaan Pusat sebelum Harumi kembali memantau reaksi katalis berkala di laboratorium saat libur Natal (A: ikut menemani di ruang istirahat luar lab, Harumi menyeduh teh dua cangkir yang sudah disiapkan sejak tahu pemain ikut; B: kirim paket nasi hangat & sup krim ke lobi Gedung Sains tepat jeda sampel ketiga; C: pamit duluan, Harumi menulis kata "kecewa" kecil di sudut buku catatan).
  - `S07` (`game/kk_saionji.rpy`, `hari_n == 24` & `slot == 3`): Makan malam Natal hangat di Rumah Saionji bersama Shigeru & Akane (A: ikut makan sup krim bersama, Shiori memotong halus saat ibunya terlalu antusias bertanya soal kampus; B: ucapkan selamat Natal dan pamit sopan; C: titipkan bingkisan daun teh panggang dengan pesan pribadi untuk keluarganya).
  - `N07` (`game/kk_nagisa_early.rpy`, `hari_n in (24,25)` & `slot == 3`): Malam Natal di Rumah Sakurajima bersama boneka kelinci Koko dan dua piring kue yang sudah disiapkan dengan penjagaan cabang `if kk_has("koko_dikenal"):` (A: tinggal menemani makan kue bersama; B: pamit karena ada urusan, dibawakan sepotong kue; C: telepon Koita agar ikut menyusul ke rumah Sakurajima).
  - `Mi09` (`game/kk_family.rpy`, `hari_n in (24,25)`): Koridor luar aula jamuan Natal Rumah Sakit Tachibana saat Miyuki gugup menghadapi orang tuanya dan keluarga Hayase Takeru (A: temani masuk sebagai teman dan Miyuki menolak halus arahan ibunya; B: tampil sebagai pasangan palsu di depan orang tua & Takeru; C: pamit di depan pintu aula sebelum acara dimulai).
- **Sinkronisasi Waktu & Slot Engine (`kk_life.rpy`) (WAJIB CEK SEBELUM MENULIS):**
  - `KK_SLOTS = ["PAGI"(0), "SIANG"(1), "SORE"(2), "MALAM"(3), "LARUT"(4), "DINI HARI"(5)]`.
  - Selalu cek `kk_window(eid)` di `game/kk_life.rpy` sebelum menulis deskripsi waktu/tanggal! Event yang terbuka di banyak slot atau banyak hari (seperti `C02`, `Y02`, `K01`) TIDAK BOLEH mengunci kalimat `"pagi 7 April"` / `"hari pertama orientasi"` jika pemain bisa memicunya saat pulang ke rumah atau di hari lain. Gunakan kondisi `if kk_slot == 0:` bila perlu, atau frasa waktu fleksibel yang cocok dengan seluruh jendela trigger-nya.
- **Aturan Anti-Skip & Dialogue Choice (WAJIB UNTUK SEMUA BAB KE DEPAN):**
  - **Jangan Skip-Skipan:** Jangan meringkas percakapan penting ke dalam satu baris narasi (seperti `"Ia mulai bercerita tentang..."`, `"Mereka mengobrol panjang lebar..."`, `"Sepuluh menit kemudian..."`). Tampilkan percakapan itu langsung lewat dialog bolak-balik yang hidup!
  - **Dialogue Choice:** Setiap kali pilihan di `kk_family_menu` / `kk_choice_panel` adalah respons verbal yang lebih enak dibaca sebagai ucapan langsung, tulis sebagai **dialogue choice** bertanda kutip (`"\"...\""`), sambil tetap menjaga jumlah & urutan opsi serta netralitas panggilan bila berbagi antara Host Chiasa dan Host Yutaka. Pilihan aksi fisik/diam tetap ditulis sebagai aksi.
- **Gaya Naskah Natural & Anti-AI (DIKUNCI KETAT):**
  - **Narator (`nar`)** HARUS tetap rapi, bersih, dan bergaya novel/VN baku-semi-baku yang nyaman dibaca (JANGAN pakai bahasa gaul/singkatan lisan seperti *udah, rame, diem, noleh, beneran, pas* di dalam `nar`).
  - **Dialog karakter** harus alami dan hidup sesuai watak masing-masing, **TETAPI bedakan bahasa lisan Indonesia yang cocok untuk latar universitas Jepang vs yang tidak cocok**:
    - *Cocok:* `nggak, kok, sih, aja, deh, dong, lho, kan, ya sudah, bentar, tumben, kelihatan, kayaknya, serius?`.
    - *Hindari (merusak imersi latar Jepang):* slang lokal/Jaksel seperti `bro, gas, lebay, matre, baper, kegeeran, sewot, cabut, pecah, notice, fix, sorry banget, good luck`.
  - Hindari kalimat penutup bergaya esai/kesimpulan moral di akhir cabang (`"bukan X, melainkan Y"`, `"tanda bahwa..."`) dan kurangi em-dash (`—`) berlebihan.
