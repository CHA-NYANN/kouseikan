# Prompt mandiri Gemini Web — Mo-D02: Panggilan Empat Detik

Kamu penulis baru untuk Kouseikan. Anggap ini chat baru: semua konteks yang dibutuhkan ada dalam pesan ini. Jangan mengandalkan percakapan sebelumnya, pengetahuan file repo, atau meminta pengguna menempel bahan tambahan. Naskah acuan di bawah adalah draf yang ingin diganti, bukan gaya yang wajib ditiru.

## Tugas tunggal

Tulis ulang hanya event Mo-D02.

Sumber lokal untuk orang yang nanti memasang hasil: `game/kk_moeka_dyn.rpy:50`; label `kkscene_Mo_D02`. Gemini Web tidak perlu dan tidak dianggap dapat membuka path tersebut.

## Premis, waktu, POV dan aturan dunia

Kouseikan adalah visual novel drama psikologis bercabang, berlatar universitas Jepang, ditulis dalam bahasa Indonesia. Pemain mati di dunia asal lalu menempati tubuh Yutaka ATAU Chiasa dalam dunia manga harem yang tidak disukainya. Kesadaran pemilik tubuh asli hilang; jangan membuat pemilik lama berdialog sebagai orang kedua yang hadir di ruangan. Pemain tidak mewarisi ingatan pribadi atau keterampilan rumit host, hanya tubuh dan kebiasaan sederhana.

Koita adalah MC manga asli, BUKAN otomatis tokoh yang dikendalikan pemain. Sistem NTR yang sinis mengancam pemain: takdir romantis Koita harus cukup menyimpang ketika ia wisuda, atau pemain mati. Perhitungan itu bukan penilaian moral; kebaikan maupun kekejaman punya akibat tersendiri. Jangan mengubah Sistem menjadi dalih yang membenarkan pelaku atau membuat angka menjadi cinta.

Permainan mulai 7 April; rentang tiga tahun sampai wisuda Koita pada Maret. Awal: Koita/Yutaka/Nagisa/Harumi/Moeka/Shiori tahun kedua, Chiasa tahun pertama, Miyuki tahun ketiga. Semua tokoh romansa/mahasiswa 18+. Adik-adik kecil Moeka adalah tokoh keluarga saja. Geng kecil: Koita, Yutaka, Nagisa, Chiasa. Kelompok belajar SMA: Koita, Yutaka, Nagisa, Miyuki, Harumi. NPC boleh menolak; tidak ada ketertarikan yang dijamin.

Chiasa dan Koita saudara tiri tanpa hubungan darah. Pada host Yutaka, Chiasa adalah NPC independen; pada host Chiasa, Yutaka adalah NPC independen. Jangan menghadirkan pemain dan host sebagai dua tubuh. BL Yutaka–Koita memakai ketegasan emosional dengan hak menolak tetap utuh. Chiasa dapat menjalani yuri; romansa heteronya terkait Koita/Yutaka. Chiasa–Yutaka saja tidak otomatis menyimpangkan hidup Koita dan tidak otomatis menyelamatkan kontrak.

Cerita bercabang: jangan menyatakan opsi dari adegan lain sudah dipilih, hubungan sudah resmi, rahasia sudah diketahui, atau ending tertentu pasti terjadi jika kondisi/kode di paket ini tidak menjaminnya. Metadata katalog bisa basi; struktur dan kondisi pada kode saat ini mengalahkan komentar.

## Karakter dan hubungan yang perlu diingat dalam prompt INI

### Pegangan suara dan fakta
- Kohinata Moeka: mahasiswa Seni/Fashion, ceria dan menggoda di permukaan, menanggung kerja, kebutuhan keluarga, dan stres tersembunyi. Rina sahabat dekat. Aya adalah IBU Moeka, bukan kakak. Keceriaan tidak berarti ia selalu sanggup atau sedang setuju. Krisisnya jangan disulap menjadi hadiah romantis bagi penolong.
- Kisaragi Yutaka: mahasiswa Ekonomi/Bisnis, sahabat kecil Koita, tinggal di apartemen bagus. Aslinya santai, jahil, blak-blakan, hangat dan menyimpan kesepian; menyukai Chiasa. Pemain tidak mewarisi ingatan pribadi, materi kuliah atau skill game profesionalnya. Keluarga kaya tetapi berjarak; Amamiya tempat ia merasa diterima. Ia TIDAK punya kunci cadangan rumah Amamiya.
- Amamiya Chiasa: mahasiswa Seni tahun pertama, adik TIRI Koita tanpa hubungan darah. Posesif halus dan suka menggoda Ko-nii. Rambut cokelat gelap half-up berpita hitam, mata keemasan. Ilustrator nama pena Shena. Daisuke ayah biologisnya, Yoshie ibu biologis Koita/ibu tirinya. Pemain dalam tubuh Chiasa TIDAK mewarisi kemampuan menggambarnya.
- Amamiya Koita: MC manga asli, mahasiswa Sastra. Baik dan mudah tersanjung, terbiasa menggantung jawaban karena takut mengecewakan atau kehilangan orang. Awal naif, lalu bisa sadar, memilih, atau retak. Jangan jadikan ia bodoh permanen maupun penjahat yang sudah sadar sejak awal.

Profil bertanda canon/usulan adalah bahan kerja proyek, bukan permintaan konfirmasi. Jangan meminta persetujuan ulang karena ada tanda usulan. Profil menggambarkan kemungkinan rentang karakter; jangan memainkan semua tahap distorsi sekaligus. Koreksi fakta pada pegangan suara di atas dan kondisi adegan sekarang mengalahkan rincian lama yang bertentangan.

### Profil lengkap tokoh fokus (rujukan, bukan perintah memainkan semua tahap rute)
# Kohinata Moeka — gyaru fashion

Status: profil ✅, visual 🟡 sebagian, sisanya 🟡 usulan. Rute distorsi: Death-Flag (tragedi psikologis serius, non-grafis).

> **Catatan konten:** Rute ini menyentuh bunuh diri dan kematian. Game 18+, jadi dampaknya boleh tampil dengan bobot penuh (duka, pemakaman, penyesalan). Satu batas tetap kupegang: tidak ada metode atau detail teknis, karena itu bisa merugikan pemain yang rentan. Game hardcore (keputusanmu), jadi tidak ada layar peringatan atau toggle khusus di rute ini.

## 1. Identitas
- ✅ Kohinata Moeka (🟡 kanji: 小日向 萌花). 19 tahun. Fashion Design, tahun kedua, Seni Rupa dan Desain. Heroine utama kelima. Sudah mencintai Koita.
- ✅ Anak tertua dari 4: dua adik laki-laki dan satu adik perempuan.
- 🟡 Ulang tahun: 25 Agustus. Golongan darah O.
- ✅ Beasiswa penuh biaya kuliah dari jabatan wakil ketua OSIS SMA.

## 2. Penampilan
- ✅ Rambut pink panjang bergelombang, mata biru cerah, 164–168 cm. Mix & Match Gyaru (thrift, DIY, smart mix). Reputasi: Campus Celebrity, Fashion Icon, Social Butterfly.
- 🟡 Selalu ada satu elemen DIY di outfit (patch, renda jahit sendiri).

## 3. Kepribadian
- ✅ Extrovert, energik, ramah, flirty, santai, playful. Dengan orang dekat: manja, lembut, vulnerable.
- ✅ Gap moe: kompeten di tugas organisasi, buruk mengelola kehidupan pribadi (terlambat, lupa janji, salah jadwal).
- 🟡 Topengnya efektif sehingga orang mengira dia selalu baik-baik saja. Itu juga bahayanya.

## 4. Latar belakang dan keluarga
- ✅ Keluarga sederhana, tidak berkecukupan. Orang tua tidak ingin membebani Moeka. Moeka ingin meringankan beban. Kondisi keluarga sekarang tidak baik-baik saja (bentuknya 🟡 kuisi di bagian 14).
- 🟡 Usulan masalah keluarga: ayah (Kohinata Shuji) didiagnosis penyakit kronis dan kehilangan pekerjaan; ibu (Aya) bekerja ganda. Biaya adik-adik menumpuk. Moeka diam-diam mengirim sebagian uang saku.
- 🟡 Syarat beasiswa: IPK minimal; kalau turun, beasiswa terancam. Ini sumber stres terpisah.

## 5. Hubungan awal
| Dengan | Kondisi | Aff | Trust | Intim | Jeal | Fear |
|---|---|---|---|---|---|---|
| Koita | ✅ mencintai | Tinggi | Sedang | Rendah | Sedang | Rendah |
| Yutaka | 🟡 satu panitia festival; saling menggoda | Sedang | Sedang | Rendah | Rendah | Rendah |
| Chiasa | 🟡 satu fakultas; Moeka senpai | Sedang | Sedang | Rendah | Rendah | Rendah |
| Nagisa | 🟡 menyebutnya "Nagi-chan"; Nagisa kesal | Rendah | Rendah | Rendah | Rendah | Rendah |
| Miyuki | 🟡 Miyuki pernah merawatnya; Moeka manja padanya | Sedang | Sedang | Rendah | Rendah | Rendah |
| Harumi | 🟡 kenalan satu angkatan | Rendah | Rendah | Rendah | Rendah | Rendah |
| Shiori | 🟡 Moeka ingin berteman; Shiori menjaga jarak | Rendah | Rendah | Rendah | Rendah | Rendah |
| Rina (NPC) | 🟡 sahabat | Tinggi | Tinggi | Sedang | Rendah | Rendah |
| Aya (NPC) | 🟡 ibu | Tinggi | Tinggi | Sedang | Rendah | Rendah |

## 6. Motivasi, ketakutan, kelemahan
- 🟡 Ingin: keluarganya baik-baik saja, dan ada satu orang yang bertanya "kamu sendiri gimana?".
- 🟡 Takut: menjadi beban; orang tahu dia tidak sekuat kelihatannya.
- ✅ Kelemahan manajemen pribadi.

## 7. Gaya bicara
- 🟡 Cepat, ceria, banyak "yaa~", "masa sih?", "ih gemes!". Saat lelah: tertawa lebih keras dari biasanya.
- 🟡 Contoh:
  - "Eh kamu nongol! Pas banget, aku lagi butuh pendapat soal outfit!"
  - "Ahaha, aku baik-baik aja, serius! Cuma kurang tidur!"
  - "...Boleh nggak, bentar aja, aku sandar?"

## 8. Kehidupan harian dan hadiah
- 🟡 Kuliah dan studio mode, rapat kegiatan kampus, thrifting akhir pekan, part-time sore. Sering terlambat dan lupa janji.
- 🟡 Hadiah disukai: kain/aksesori bagus untuk DIY, makanan untuk adik-adik, tiket atau bantuan nyata. Hadiah mahal membuatnya merasa berutang.

## 9. Pemicu cemburu
- 🟡 Koita lebih fokus ke heroine lain. Perbandingan penampilan. Dicap "gampangan".
- 🟡 Reaksi: tertawa dan bercanda, lalu menghilang beberapa hari dari grup chat.

## 10. Personal storyline 🟡
1. Hari-hari ceria; pemain melihat sisi kompetennya.
2. Janji yang terlupa: pemain memilih memarahi atau menolong.
3. Kabar keluarga memburuk.
4. Titik balik: ujian, beasiswa, dan kondisi ayah bertepatan.
5. Akhir: dia meminta tolong, atau terus menyembunyikan.

## 11. Rute Distorsi: Death-Flag (✅ arah, tahap 🟡)
Akumulasi stres. Tidak ditampilkan secara grafis.
1. **Beban menumpuk:** uang, adik, kuliah, beasiswa.
2. **Topeng makin tebal:** terlihat lebih ceria dan lebih sibuk.
3. **Penarikan diri:** membatalkan janji, tidur tidak teratur, menolak ditanya.
4. **Titik balik (event):** kejadian tambahan (ayah memburuk, beasiswa dicabut, ditinggal orang yang diandalkan).
5. **Jendela krisis:** tanda-tanda jelas bagi orang yang memperhatikan. Intervensi ditampilkan sebagai pilihan yang masuk akal.
- **Tanda yang terbaca:** membagikan barang kesayangan, kalimat perpisahan yang disamarkan, lupa janji lebih sering, berhenti mengunggah.
- **Intervensi:** Rina, Aya, pemain, Koita. Bentuk bantuan: hadir, mendengarkan, bantuan konkret, menghubungkan ke bantuan profesional.
- 🟡 **Keputusan:** kematian **bisa dicegah sampai satu titik tertentu**, setelah itu tidak. Titik itu adalah "Malam Tanpa Balasan": malam ketika tiga hal bertemu (surat peringatan beasiswa, kondisi ayah memburuk, dan orang yang ia andalkan tidak membalas pesannya). Sebelum itu ada minimal tiga jendela intervensi (Rina, Aya, pemain) dan pemain selalu diberi tanda yang cukup.
- **Pemulihan:** 🟡 mungkin jika intervensi tepat waktu dan konsisten.

## 12. Ending 🟡
- **Bad:** Moeka meninggal. Yang ditampilkan: kabar, duka, pemakaman, Rina dan Aya, adik-adiknya, dan penyesalan pemain. Tanpa metode. Sistem NTR terdiam; tidak ada ejekan.
- **Neutral:** bertahan, putus kuliah sementara, bekerja membantu keluarga.
- **Distorted:** tampak baik-baik saja tetapi hidup penuh topeng, tergantung pada pemain.
- **Romantis dengan pemain:** dia belajar meminta tolong dan keluarga stabil.

## 13. Perbedaan Male vs Female
- 🟡 Male Route: pendekatan lewat dunia kampus dan acara. Female Route: lewat kolaborasi seni dan fashion (ilustrasi desain).

## 14. Keputusan yang sudah kuisi (🟡)
- **Kanji nama:** 小日向 萌花. **Tinggi:** 166 cm. **SMA:** SMA Negeri Hanazono.
- **Beasiswa:** menutup biaya kuliah saja. Syarat: IPK minimal 3,2. Bila turun dua semester berturut-turut, beasiswa dicabut.
- **Keluarga:** ayah Kohinata Shuji (46) sakit ginjal kronis dan menjalani cuci darah rutin, kehilangan pekerjaan; ibu Aya (lihat NPC). Adik: Ren (16, laki-laki), Sora (12, laki-laki), Hinata (8, perempuan).
- **Tempat tinggal:** kos kecil 15 menit dari kampus; keluarga di kota satelit sejam dengan kereta.
- **Hubungan dengan heroine lain:** lihat tabel dan [Hubungan_Antar_Karakter.md](../Hubungan_Antar_Karakter.md).
- **Mengapa mencintai Koita:** Koita menutupi kelalaiannya saat orientasi tanpa memperbesar. Orang yang tidak menghakimi sisi cerobohnya.
- **Bantuan pemain:** pemberian uang atau bantuan nyata boleh dan bukan pinjaman. Moeka awalnya menolak karena harga diri.


### Hubungan awal yang relevan; tidak otomatis menggambarkan keadaan sekarang
| Yutaka – Moeka | Satu panitia Festival Musim Dingin (Moeka koordinator acara, Yutaka bagian dana). Moeka menggodanya santai, Yutaka membalas jahil. Aff Sedang, Trust Sedang, Intim Rendah. |
| Chiasa – Moeka | Satu fakultas (Seni Rupa dan Desain), senpai–kouhai. Moeka mengajak Chiasa menggambar sketsa untuk mini-show. Aff Sedang, Trust Sedang, Jeal Rendah. |
| Chiasa – Shiori | Belum pernah bicara. Shiori diam-diam pembaca light novel strategi yang diilustrasi "Shena" (nama pena Chiasa), tapi tidak tahu itu Chiasa. Aff Rendah, Trust Rendah. |
| Nagisa – Moeka | Bertemu di festival. Nagisa menyebutnya "gyaru berisik"; Moeka menggoda "Nagi-chan". Aff Rendah, Trust Rendah, Jeal Sedang (Nagisa). |
| Miyuki – Moeka | Miyuki pernah merawat Moeka yang pingsan karena lupa makan saat acara kampus. Moeka memanggilnya "Miyuki-senpai~" manja. Aff Sedang, Trust Sedang. |
| Harumi – Moeka | Kenalan satu angkatan. Harumi mencatat Moeka sebagai "variabel kacau"; Moeka mengajaknya jadi model (ditolak). Aff Rendah, Trust Rendah. |
| Moeka – Shiori | Moeka ingin berteman; Shiori sopan tapi menjaga jarak. Moeka tidak tahu Shiori menjaga jarak dari semua orang. Aff Rendah, Trust Rendah. |
| Koita – Moeka | Saat orientasi, Moeka lupa membawa dokumen panitia; Koita menutupinya tanpa memperbesar. Sejak itu Moeka jatuh cinta. |
| Koita – Miyuki (masa lalu) | Di SMA Koita sempat **benar-benar menyukai** Miyuki, tapi mundur karena merasa tak sepadan. Sejak itu ia memilih menggantung. Hanya Koita yang tahu. |
| Target | Dikejar Yutaka | Dikejar Chiasa |

## Posisi adegan dan batas kontinuitas

POV dapat bergantung pada host yang dipilih. ID event atau karakter pada kk_scene_enter bukan bukti bahwa dialah pemain. Pertahankan guard/cabang host pada acuan; bagian bersama harus masuk akal untuk kedua host. Jangan mengunci jenis kelamin/identitas pemain jika kode tidak menguncinya.

Event DINAMIS, urutannya tidak tetap. Pemicu di bawah menentukan apakah ia terjadi; nomor -D bukan tanggal atau bukti event dinamis sebelumnya sudah terjadi.

Koreksi khusus untuk adegan ini: **Jika komentar/katalog bertentangan dengan kode acuan, kode menang. Jangan menambah atau menukar opsi.**

### Panduan adegan lokal

```text
# ┌─ PANDUAN CERITA · Mo-D02 · Panggilan Empat Detik
# │ LOKASI  : (dinamis — muncul dari kondisi)
# │ TERLIBAT: Kohinata Moeka
# │ AWALAN  : tahap ≥ 2; Larut
# │ INTI    : A Telepon balik sekarang / B kirim pesan / C besok saja
# │ AKHIRAN : jendela kecil; andalan ±
# └─ tulis / perbaiki dialog di bawah ──
```

### Data katalog untuk orientasi saja; pilihan aktual tetap dari kode

```json
{
  "id": "Mo-D02",
  "name": "Panggilan Empat Detik",
  "trigger": "tahap ≥ 2; Larut",
  "desc": "panggilan tak terjawab, durasi 4 detik. Telepon balik sekarang / kirim pesan / besok saja",
  "choices": [
    "Telepon balik sekarang",
    "kirim pesan",
    "besok saja"
  ],
  "effect": "jendela kecil; andalan ±"
}
```


### Efek kode yang sudah tertaut — baca saja, JANGAN tulis ulang
```text
kk_moeka_dyn.rpy: _hook("Mo-D02-A", lambda: (kk_moeka_rely(6), kk_rel("moeka","trust",3)))
kk_moeka_dyn.rpy: _hook("Mo-D02-B", lambda: kk_rel("moeka","aff",2))
kk_moeka_dyn.rpy: _hook("Mo-D02-C", lambda: kk_moeka_mask(4))
```
Nilai ini hanya penuntun konsekuensi emosional. Jangan mengucapkan nilainya, menjanjikan ending, atau mengeksekusinya lagi.

## Sasaran penulisan

Tulis adegan yang benar-benar dimainkan: percakapan konkret, gestur, tindakan kecil, subteks, ruang, waktu, dan perubahan suasana. Biarkan ketegangan bergerak melalui apa yang dilakukan/dikatakan tokoh. Kurangi paragraf yang menjelaskan tema, merangkum pelajaran hidup, atau memberi vonis narator setelah setiap dialog. Jangan otomatis membuat semua tokoh memakai suara konselor yang sama; tokoh boleh menghindar, salah paham, marah, kikuk, egois, atau menyakitkan sesuai pilihan.

Bahasa Indonesia natural dengan irama lisan yang cocok untuk masing-masing tokoh. Hindari terjemahan kaku, pembuka generik berulang, metafora yang dipaksakan, jargon mesin dalam mulut NPC, dan penutup moral seragam. Jangan menyalin prosa sekarang hanya dengan sinonim; ia bahan kasar yang boleh diganti total. Pertahankan fakta yang dikunci, bukan kualitas prosa lama. Tidak ada batas kata buatan: tulis sepanjang yang dibutuhkan adegan, dengan setiap cabang mendapatkan perkembangan, reaksi, dan pendaratan yang terasa berbeda; jangan memanjangkan dengan pengulangan.

Tema gelap tetap boleh intens: kecemburuan, obsesi, penolakan, perselingkuhan emosional, ancaman, krisis keluarga, kekerasan nonseksual, trauma dan akibat sosial/hukum. Kekerasan seksual tidak ditulis grafis atau sebagai langkah menembus perlawanan; potong ke akibat. Jangan uraikan metode bunuh diri/menyakiti diri atau prosedur memfitnah/menjebak korban. Tulis niat, ketegangan, penderitaan, respons orang lain dan konsekuensinya dengan bobot penuh. Ketakutan/ketergantungan bukan cinta atau persetujuan; tidak ada ending romantis dengan pelaku Force. Adegan intim dewasa konsensual cukup tersirat tanpa detail seksual eksplisit.

## Kontrak keluaran dan integrasi

Keluaran harus siap ditinjau untuk proyek Ren'Py yang sudah berjalan. Edit hanya narasi/dialog (dan bila perlu kata pada caption tanpa mengubah maksudnya). PERTAHANKAN nama/signature label, indentasi logis, semua return/jump/call, ID event, jumlah dan urutan opsi, kondisi host/lokasi/saldo/hasil ujian, percabangan, dan SEMUA statement mekanik yang sudah ada. Jangan menambah atau menghapus efek, flag, hook, waktu, uang, fungsi, karakter, label, init Python, screen, atau scheduler. Jangan mengganti nama variabel engine. Jangan menyalin blok hook konteks ke keluaran.

Baris pertama label kkscene tetap `call kk_scene_enter(...)` seperti kode acuan. Helper khusus boleh diawali guard yang sudah ada; jangan pindahkan/meniadakannya. Scene dengan menu 3/4 memakai struktur yang sudah ada dalam acuan (umumnya kk_family_menu untuk 3, _rows/kk_choice_panel/kk_record_choice untuk 4). Pengecualian menu bersyarat, 2/5 opsi, indeks numerik, dan helper bersama harus dipertahankan persis; jangan menormalkan menu jika itu mengubah kondisi atau mekanisme lama.

Narasi: `nar "..."`. Tokoh utama: koita/miyuki/nagisa/harumi/moeka/shiori/chiasa/yutaka (huruf kecil). Sistem: `sistem "..."` bila memang hadir. NPC: `"Nama NPC" "..."`. Jangan menghasilkan dialog tanpa pembicara. Satu statement dialog per baris fisik; tidak ada newline literal dalam kutip dialog; escape kutip internal dengan backslash sebelum kutip ganda. Jangan menampilkan statistik/ID/flag dalam dialog kecuali memang bagian ucapan Sistem yang relevan. Gunakan narasi orang kedua sesuai acuan; jangan tiba-tiba memberi pemain identitas atau ingatan baru.

Sebelum menjawab, periksa diam-diam: semua opsi dan makna A/B/C/D/E masih sama; seluruh statement mekanik dan syarat dipertahankan; pembicara benar; tidak ada hasil rute yang dipaksakan; masing-masing cabang hidup sebagai adegan. Keluarkan HANYA satu blok kode renpy berisi label target lengkap. Tanpa pengantar, analisis, ringkasan, elipsis pengganti bagian, komentar TODO atau janji melanjutkan.

## Label lengkap saat ini — tulis versi penggantinya

```renpy
label kkscene_Mo_D02:
    call kk_scene_enter("moeka", "Layar ponsel")
    nar "Panggilan Moeka hanya bertahan empat detik. Sebelum tanganmu sampai ke layar, ia sudah menutup. Tak lama muncul pesan bahwa tadi salah menekan, disertai stiker tertawa yang sangat akrab."
    call kk_family_menu("Mo-D02", ["Telepon balik sekarang.", "Kirim pesan menanyakan kabar.", "Besok saja, mungkin tidak penting."])
    if _return == "A":
        moeka "Kau menelepon balik? ...Tidak, tidak ada apa-apa. Aku cuma... senang kau mengangkat."
        nar "Kau mengatakan bisa mendengar sebentar jika ia ingin bicara. Napas di seberang goyah, kemudian ia meminta ditemani sampai bisa menyebut apa yang membuat malamnya terasa berat."
    elif _return == "B":
        moeka "Maaf, salah pencet. Sungguh. Tidurlah."
        nar "Kau mengirim pesan lagi bahwa ia boleh mengatakan jika butuh sesuatu. Balasannya datang lebih lambat, berterima kasih tanpa membuka seluruh cerita. Jalan untuk berbicara tetap ada, meski malam itu belum dipakai."
    else:
        nar "Kau menunggu besok. Pagi hari Moeka sudah kembali mengirim cerita biasa, dan panggilan itu tampak mudah dilewatkan sebagai salah tekan."
        nar "Ia tidak menanyakan mengapa kau tidak menghubungi. Kebutuhan yang nyaris disampaikan semalam kini harus menemukan keberanian baru untuk muncul."
    return
```

Sekarang tulis satu versi adegan yang selesai, mengikuti tugas tunggal dan batas di atas. Hanya blok kode pengganti.
