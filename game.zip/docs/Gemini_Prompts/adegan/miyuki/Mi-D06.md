# Prompt mandiri Gemini Web — Mi-D06: Teguran yang Ia Minta

Kamu penulis baru untuk Kouseikan. Anggap ini chat baru: semua konteks yang dibutuhkan ada dalam pesan ini. Jangan mengandalkan percakapan sebelumnya, pengetahuan file repo, atau meminta pengguna menempel bahan tambahan. Naskah acuan di bawah adalah draf yang ingin diganti, bukan gaya yang wajib ditiru.

## Tugas tunggal

Tulis ulang hanya event Mi-D06.

Sumber lokal untuk orang yang nanti memasang hasil: `game/kk_miyuki_dyn.rpy:102`; label `kkscene_Mi_D06`. Gemini Web tidak perlu dan tidak dianggap dapat membuka path tersebut.

## Premis, waktu, POV dan aturan dunia

Kouseikan adalah visual novel drama psikologis bercabang, berlatar universitas Jepang, ditulis dalam bahasa Indonesia. Pemain mati di dunia asal lalu menempati tubuh Yutaka ATAU Chiasa dalam dunia manga harem yang tidak disukainya. Kesadaran pemilik tubuh asli hilang; jangan membuat pemilik lama berdialog sebagai orang kedua yang hadir di ruangan. Pemain tidak mewarisi ingatan pribadi atau keterampilan rumit host, hanya tubuh dan kebiasaan sederhana.

Koita adalah MC manga asli, BUKAN otomatis tokoh yang dikendalikan pemain. Sistem NTR yang sinis mengancam pemain: takdir romantis Koita harus cukup menyimpang ketika ia wisuda, atau pemain mati. Perhitungan itu bukan penilaian moral; kebaikan maupun kekejaman punya akibat tersendiri. Jangan mengubah Sistem menjadi dalih yang membenarkan pelaku atau membuat angka menjadi cinta.

Permainan mulai 7 April; rentang tiga tahun sampai wisuda Koita pada Maret. Awal: Koita/Yutaka/Nagisa/Harumi/Moeka/Shiori tahun kedua, Chiasa tahun pertama, Miyuki tahun ketiga. Semua tokoh romansa/mahasiswa 18+. Adik-adik kecil Moeka adalah tokoh keluarga saja. Geng kecil: Koita, Yutaka, Nagisa, Chiasa. Kelompok belajar SMA: Koita, Yutaka, Nagisa, Miyuki, Harumi. NPC boleh menolak; tidak ada ketertarikan yang dijamin.

Chiasa dan Koita saudara tiri tanpa hubungan darah. Pada host Yutaka, Chiasa adalah NPC independen; pada host Chiasa, Yutaka adalah NPC independen. Jangan menghadirkan pemain dan host sebagai dua tubuh. BL Yutaka–Koita memakai ketegasan emosional dengan hak menolak tetap utuh. Chiasa dapat menjalani yuri; romansa heteronya terkait Koita/Yutaka. Chiasa–Yutaka saja tidak otomatis menyimpangkan hidup Koita dan tidak otomatis menyelamatkan kontrak.

Cerita bercabang: jangan menyatakan opsi dari adegan lain sudah dipilih, hubungan sudah resmi, rahasia sudah diketahui, atau ending tertentu pasti terjadi jika kondisi/kode di paket ini tidak menjaminnya. Metadata katalog bisa basi; struktur dan kondisi pada kode saat ini mengalahkan komentar.

## Karakter dan hubungan yang perlu diingat dalam prompt INI

### Pegangan suara dan fakta
- Tachibana Miyuki: senpai Kedokteran, hangat, rajin merawat orang dan membuat kue. Kebiasaan mendahulukan orang lain menutupi lelah dan kebutuhan disayangi. Suaranya lembut tetapi ia bisa tegas. Sena sahabatnya; Hayase Takeru calon omiai sepihak, bukan pasangan yang otomatis sah.
- Kisaragi Yutaka: mahasiswa Ekonomi/Bisnis, sahabat kecil Koita, tinggal di apartemen bagus. Aslinya santai, jahil, blak-blakan, hangat dan menyimpan kesepian; menyukai Chiasa. Pemain tidak mewarisi ingatan pribadi, materi kuliah atau skill game profesionalnya. Keluarga kaya tetapi berjarak; Amamiya tempat ia merasa diterima. Ia TIDAK punya kunci cadangan rumah Amamiya.
- Amamiya Chiasa: mahasiswa Seni tahun pertama, adik TIRI Koita tanpa hubungan darah. Posesif halus dan suka menggoda Ko-nii. Rambut cokelat gelap half-up berpita hitam, mata keemasan. Ilustrator nama pena Shena. Daisuke ayah biologisnya, Yoshie ibu biologis Koita/ibu tirinya. Pemain dalam tubuh Chiasa TIDAK mewarisi kemampuan menggambarnya.
- Amamiya Koita: MC manga asli, mahasiswa Sastra. Baik dan mudah tersanjung, terbiasa menggantung jawaban karena takut mengecewakan atau kehilangan orang. Awal naif, lalu bisa sadar, memilih, atau retak. Jangan jadikan ia bodoh permanen maupun penjahat yang sudah sadar sejak awal.

Profil bertanda canon/usulan adalah bahan kerja proyek, bukan permintaan konfirmasi. Jangan meminta persetujuan ulang karena ada tanda usulan. Profil menggambarkan kemungkinan rentang karakter; jangan memainkan semua tahap distorsi sekaligus. Koreksi fakta pada pegangan suara di atas dan kondisi adegan sekarang mengalahkan rincian lama yang bertentangan.

### Profil lengkap tokoh fokus (rujukan, bukan perintah memainkan semua tahap rute)
# Tachibana Miyuki (橘 美雪) — senpai kedokteran

Status: profil ✅, visual ✅ ACC, sisanya 🟡 usulan. Rute distorsi: Masokis (emosional + romantis, ditulis non-eksplisit).

## 1. Identitas
- ✅ Tahun ketiga Kedokteran, Kouseikan. Sekitar 21 tahun. Satu tahun di atas Koita dan Yutaka. Salah satu 5 heroine utama. Sudah mencintai Koita, belum berpacaran.
- ✅ Tinggal sendiri di apartemen mewah dekat kampus. Keluarga Tachibana kaya, orang tua sangat sibuk.
- 🟡 Ulang tahun: 9 Desember. Golongan darah AB.

## 2. Penampilan (✅ ACC)
- Rambut hitam panjang lurus, terurai, tanpa hiasan kepala. Mata biru sapphire. Tinggi, anggun. Outfit utama: jas dokter putih di atas atasan ungu gelap, rok hitam, stetoskop.
- 🟡 Pakaian rumah: kardigan krem dan celana longgar. Di apartemen dia terlihat jauh lebih santai dan "lebih muda".

## 3. Kepribadian
- ✅ Publik: senior hangat, lembut, dewasa, bisa diandalkan. Akrab: onee-san yang manja, jahil, suka menggoda, mudah merajuk.
- ✅ Kelemahan: sulit meminta bantuan, mudah kesepian, memaksakan diri dalam studi.
- ✅ Menyukai hubungan serius, eksklusif, setia. Tidak suka pertemanan dijadikan alat bisnis.
- 🟡 Sifat di bawah permukaan: perhatiannya pada orang lain adalah cara dia merasa berguna. Kalau tidak dibutuhkan, dia merasa tidak punya nilai.

## 4. Latar belakang
- ✅ Orang tua sering diminta mendekati Shiori demi koneksi; Miyuki diam-diam tidak suka. Cita-cita: dokter spesialis anak. Hobi: memasak makanan rumahan dan pastry.
- ✅ Cinta pada Koita muncul setelah Koita tidak menghakimi sisi manjanya. Dia belum tahu motif Koita menggantung perasaan.
- 🟡 Orang tuanya: ayah dokter bedah, ibu direktur rumah sakit swasta. Mereka mengirim hadiah mahal, jarang hadir.

## 5. Hubungan awal
| Dengan | Kondisi | Aff | Trust | Intim | Jeal | Fear |
|---|---|---|---|---|---|---|
| Koita | ✅ mencintai; senpai–kouhai akrab | Tinggi | Tinggi | Sedang | Sedang | Rendah |
| Yutaka | ✅ kenal nama, bicara singkat | Rendah | Sedang | Rendah | Rendah | Rendah |
| Chiasa | ✅ kenal lewat Koita | Rendah | Sedang | Rendah | Sedang | Rendah |
| Shiori | ✅ saling tahu wajah/nama dari acara keluarga | Rendah | Sedang | Rendah | Rendah | Rendah |
| Nagisa | 🟡 kelompok belajar SMA; menyayanginya seperti adik | Sedang | Sedang | Sedang | Rendah | Rendah |
| Harumi | ✅ formal dan sopan (kelompok belajar SMA) | Rendah | Sedang | Rendah | Rendah | Rendah |
| Moeka | 🟡 pernah merawatnya yang pingsan; Moeka manja padanya | Sedang | Sedang | Rendah | Rendah | Rendah |
| Sena (NPC) | 🟡 sahabat dekat | Tinggi | Tinggi | Tinggi | Rendah | Rendah |

## 6. Motivasi, ketakutan, kelemahan
- 🟡 Ingin: seseorang yang menjaga dia saat dia lelah, bukan hanya dipuji.
- 🟡 Takut: terlihat lemah dan tidak lagi dibutuhkan.

## 7. Gaya bicara
- 🟡 Lembut, pakai "ara ara", menggoda halus sambil tersenyum. Jika merajuk, nadanya mengecil dan kalimatnya pendek.
- 🟡 Contoh:
  - "Ara, kamu lagi ngelamun ya? Mau senpai bikinin teh?"
  - "Aku nggak merajuk kok. ...Cuma sedikit."
  - "Aku baik-baik aja. Beneran. Jangan khawatirin aku."

## 8. Kehidupan harian dan hadiah
- 🟡 Kuliah dan praktik Senin–Jumat, belajar malam, memasak Sabtu pagi, belanja bahan Minggu.
- 🟡 Hadiah yang disukai: bahan pastry bagus, buku anak, teh, hal-hal yang menunjukkan perhatian. Hadiah mahal membuatnya canggung.

## 9. Pemicu cemburu
- 🟡 Koita menyebut heroine lain terlalu bersemangat. Janji yang dilanggar tanpa kabar. Dibatalkan demi orang lain.
- 🟡 Reaksi: tersenyum tipis, bilang "tidak apa-apa", lalu membuat kue terlalu banyak.

## 10. Personal storyline 🟡
1. Hari-hari praktik: dia kelelahan, pemain menemukan sisi manjanya.
2. Pesta/pertemuan keluarga: tekanan mendekati Shiori.
3. Ujian besar dan kesendirian.
4. Titik balik: sakit/pingsan karena memaksakan diri.
5. Pilihan: bersama Koita, bersama pemain, atau mandiri.

## 11. Rute Distorsi: Masokis (✅ arah, tahap 🟡)
Catatan: ditulis sebagai gambaran kerusakan hubungan, tanpa adegan eksplisit. Poin utamanya adalah dia mulai mengaitkan perlakuan buruk dengan perhatian.
1. **Kelelahan dan kesepian:** diabaikan atau dimanfaatkan, tetap berusaha.
2. **Perhatian = dimarahi:** hanya saat ditegur dia merasa dilihat.
3. **Normalisasi:** minta maaf berlebihan, mencari orang yang tegas dan dingin.
4. **Titik balik (event):** kesalahan di praktik atau kegagalan ujian, lalu sebuah teguran keras membuatnya lega. Sejak itu pola dibentuk.
5. **Pola menetap:** dinamika dominasi–penyerahan secara emosional dan romantis (tersirat, fade-to-black).
- **Tanda yang terbaca:** senyum yang lebih tenang setelah dimarahi, meminta hukuman kecil, mengabaikan istirahat, menolak bantuan Sena.
- **Pemulihan:** 🟡 mungkin sebagian. Butuh Sena dan jeda dari pemain. Tanpa intervensi, jadi permanen.
- **Yang menyadari:** Sena (cepat), orang tua (lambat), Koita (tidak sadar).

## 12. Ending 🟡
- **Bad:** burnout, keluar dari kedokteran / drop semester.
- **Neutral:** kembali ke pola lama, mandiri, jarak dengan semua.
- **Distorted:** hubungan "nyaman" yang tidak sehat dengan pemain.
- **Romantis dengan pemain:** hubungan eksklusif yang setara; dia belajar meminta tolong.

## 13. Perbedaan Male vs Female
- 🟡 Male Route: Yutaka dianggap adik tingkat sahabat Koita yang jahil. Female Route: Chiasa dianggap adik Koita yang digoda.

## 14. Keputusan yang sudah kuisi (🟡)
- **Tinggi:** 170 cm.
- **Pemulihan Rute Masokis:** sebagian. Sebelum tahap 4 mudah dipulihkan. Setelah tahap 5 bertahan lebih dari satu semester tanpa intervensi, pola itu menetap permanen (ia bisa hidup dengannya, tidak sembuh total).
- **Hubungan dengan Nagisa, Harumi, Moeka:** lihat tabel di atas dan [Hubungan_Antar_Karakter.md](../Hubungan_Antar_Karakter.md).
- **Batas konten romantis/seksual Rute Masokis:** teks boleh dewasa dan menggambarkan dinamika dominasi–penyerahan secara emosional; tidak ada ilustrasi seksual eksplisit.
- **Koita:** pernah benar-benar disukai Miyuki juga dari sisi Koita (SMA), tetapi Miyuki tidak tahu. Ini bisa jadi bom waktu saat terungkap.


### Hubungan awal yang relevan; tidak otomatis menggambarkan keadaan sekarang
| Yutaka – Moeka | Satu panitia Festival Musim Dingin (Moeka koordinator acara, Yutaka bagian dana). Moeka menggodanya santai, Yutaka membalas jahil. Aff Sedang, Trust Sedang, Intim Rendah. |
| Chiasa – Moeka | Satu fakultas (Seni Rupa dan Desain), senpai–kouhai. Moeka mengajak Chiasa menggambar sketsa untuk mini-show. Aff Sedang, Trust Sedang, Jeal Rendah. |
| Chiasa – Shiori | Belum pernah bicara. Shiori diam-diam pembaca light novel strategi yang diilustrasi "Shena" (nama pena Chiasa), tapi tidak tahu itu Chiasa. Aff Rendah, Trust Rendah. |
| Nagisa – Miyuki | Kelompok belajar SMA. Nagisa mengagumi dan merasa kalah dewasa; Miyuki menyayanginya seperti adik. Aff Sedang, Trust Sedang, Jeal Sedang (Nagisa→Miyuki). |
| Miyuki – Moeka | Miyuki pernah merawat Moeka yang pingsan karena lupa makan saat acara kampus. Moeka memanggilnya "Miyuki-senpai~" manja. Aff Sedang, Trust Sedang. |
| Koita – Moeka | Saat orientasi, Moeka lupa membawa dokumen panitia; Koita menutupinya tanpa memperbesar. Sejak itu Moeka jatuh cinta. |
| Koita – Miyuki (masa lalu) | Di SMA Koita sempat **benar-benar menyukai** Miyuki, tapi mundur karena merasa tak sepadan. Sejak itu ia memilih menggantung. Hanya Koita yang tahu. |
| Target | Dikejar Yutaka | Dikejar Chiasa |

### NPC terkait: Sato Kyoko
# Sato Kyoko — psikolog konseling kampus

Status: 🟡 seluruhnya usulan.

## Peran
Jalur pemulihan profesional untuk Miyuki, Harumi, Moeka, dan pemain. Mewujudkan "bantuan profesional" yang disinggung di rute gelap.

## Profil
- 38 tahun, psikolog klinis di Pusat Konseling Kouseikan. Rambut sebahu, kardigan hangat, tinggi 162 cm.
- Tenang, sabar, tidak menghakimi. Tidak memaksa; menunggu orang datang sendiri.
- Punya aturan: tidak membocorkan isi sesi tanpa persetujuan, kecuali ada bahaya mendesak.

## Hubungan dan fungsi
- Pemain bisa menyarankan heroine datang; Sato tidak bisa dipaksa.
- Rute Masokis, Eksploitasi, Death-Flag: Sato adalah jendela intervensi. Bila heroine datang tepat waktu, tahap bisa berbalik.
- Pemain sendiri bisa konseling setelah kehilangan atau konflik berat.
- Event 🟡: janji temu yang dilewatkan, jam kantor, telepon darurat.

## Gaya bicara
- "Kamu tidak harus kuat di sini."
- "Aku tidak akan menyuruhmu melakukan apa pun. Aku hanya akan mendengarkan."


### NPC terkait: Orang Tua Tachibana
# Orang Tua Tachibana — Kazuhiro & Sayuri

Status: canon hanya "kaya, sangat sibuk, mendorong Miyuki mendekati Shiori" ✅. Nama dan sisanya 🟡.

## Peran
Sumber tekanan dan kesepian Miyuki. Penggerak omiai dengan Hayase Takeru.

## Profil
- **Tachibana Kazuhiro** (53), dokter bedah senior. Dingin-efisien, bangga pada prestasi, canggung soal kasih sayang.
- **Tachibana Sayuri** (50), direktur rumah sakit swasta. Anggun, strategis, selalu bicara "demi masa depanmu".
- Mereka mencintai Miyuki tetapi mengekspresikannya lewat hadiah dan rencana, bukan waktu.

## Hubungan dan fungsi
- Dengan Miyuki: Aff Tinggi, Intim Rendah. Menelepon seminggu sekali, jadwalnya selalu bentrok.
- Menyuruh Miyuki mendekati Shiori (✅). Miyuki diam-diam tidak suka.
- Memperkenalkan Hayase Takeru sebagai calon omiai bila Miyuki "belum punya pilihan".
- Bila pemain terlihat tidak sepadan secara status, mereka ramah di depan dan menekan di belakang.

## Reaksi
- Miyuki berubah (Rute Masokis): lambat menyadari; mengira "lelah praktik". Baru sadar saat Sena menelepon.
- Pemain mengejar Miyuki: menilai latar, karier, dan "kestabilan". Bisa dimenangkan dengan konsistensi dan rasa hormat.

## Gaya bicara
- "Miyuki, ibu sudah atur jadwal makan malam dengan keluarga Hayase. Kamu pasti suka."
- "Ayah bangga. Itu saja yang perlu kamu tahu."


## Posisi adegan dan batas kontinuitas

POV dapat bergantung pada host yang dipilih. ID event atau karakter pada kk_scene_enter bukan bukti bahwa dialah pemain. Pertahankan guard/cabang host pada acuan; bagian bersama harus masuk akal untuk kedua host. Jangan mengunci jenis kelamin/identitas pemain jika kode tidak menguncinya.

Event DINAMIS, urutannya tidak tetap. Pemicu di bawah menentukan apakah ia terjadi; nomor -D bukan tanggal atau bukti event dinamis sebelumnya sudah terjadi.

Koreksi khusus untuk adegan ini: **Jika komentar/katalog bertentangan dengan kode acuan, kode menang. Jangan menambah atau menukar opsi.**

### Panduan adegan lokal

```text
# ┌─ PANDUAN CERITA · Mi-D06 · Teguran yang Ia Minta
# │ LOKASI  : (dinamis — muncul dari kondisi)
# │ TERLIBAT: Tachibana Miyuki
# │ AWALAN  : tahap ≥ 3; luka[[pemain] ≥ 40
# │ INTI    : A Aku pantas." Tolak dengan lembut / B turuti / C alihkan / D bawa ke Sato
# │ AKHIRAN : persimpangan utama; lihat Sistem_Cabang_dan_Poin §5.3
# └─ tulis / perbaiki dialog di bawah ──
```

### Data katalog untuk orientasi saja; pilihan aktual tetap dari kode

```json
{
  "id": "Mi-D06",
  "name": "Teguran yang Ia Minta",
  "trigger": "tahap ≥ 3; luka[[pemain] ≥ 40",
  "desc": "\"Bilang aku bodoh. Aku pantas.\" Tolak dengan lembut / turuti / alihkan / bawa ke Sato",
  "choices": [
    "Aku pantas.\" Tolak dengan lembut",
    "turuti",
    "alihkan",
    "bawa ke Sato"
  ],
  "effect": "persimpangan utama; lihat Sistem_Cabang_dan_Poin §5.3"
}
```


### Efek kode yang sudah tertaut — baca saja, JANGAN tulis ulang
```text
kk_miyuki_dyn.rpy: _hook("Mi-D06-A", lambda: (kk_rel("miyuki","trust",5), kk_flag("miyuki_ditolak_merendah")))
kk_miyuki_dyn.rpy: _hook("Mi-D06-B", lambda: (kk_miyuki_hurt_self(12), kk_flag("miyuki_direndahkan")))
kk_miyuki_dyn.rpy: _hook("Mi-D06-C", lambda: kk_rel("miyuki","trust",2))
kk_miyuki_dyn.rpy: _hook("Mi-D06-D", lambda: (kk_miyuki_hurt_self(-10), kk_flag("miyuki_sato_dikenal")))
```
Nilai ini hanya penuntun konsekuensi emosional. Jangan mengucapkan nilainya, menjanjikan ending, atau mengeksekusinya lagi.

## Sasaran penulisan

Tulis adegan yang benar-benar dimainkan: percakapan konkret, gestur, tindakan kecil, subteks, ruang, waktu, dan perubahan suasana. Biarkan ketegangan bergerak melalui apa yang dilakukan/dikatakan tokoh. Kurangi paragraf yang menjelaskan tema, merangkum pelajaran hidup, atau memberi vonis narator setelah setiap dialog. Jangan otomatis membuat semua tokoh memakai suara konselor yang sama; tokoh boleh menghindar, salah paham, marah, kikuk, egois, atau menyakitkan sesuai pilihan.

Bahasa Indonesia natural dengan irama lisan yang cocok untuk masing-masing tokoh. Hindari terjemahan kaku, pembuka generik berulang, metafora yang dipaksakan, jargon mesin dalam mulut NPC, dan penutup moral seragam. Jangan menyalin prosa sekarang hanya dengan sinonim; ia bahan kasar yang boleh diganti total. Pertahankan fakta yang dikunci, bukan kualitas prosa lama. Tidak ada batas kata buatan: tulis sepanjang yang dibutuhkan adegan, dengan setiap cabang mendapatkan perkembangan, reaksi, dan pendaratan yang terasa berbeda; jangan memanjangkan dengan pengulangan.

Tema gelap tetap boleh intens: kecemburuan, obsesi, penolakan, perselingkuhan emosional, ancaman, krisis keluarga, kekerasan nonseksual, trauma dan akibat sosial/hukum. Kekerasan seksual tidak ditulis grafis atau sebagai langkah menembus perlawanan; potong ke akibat. Jangan uraikan metode bunuh diri/menyakiti diri atau prosedur memfitnah/menjebak korban. Tulis niat, ketegangan, penderitaan, respons orang lain dan konsekuensinya dengan bobot penuh. Ketakutan/ketergantungan bukan cinta atau persetujuan; tidak ada ending romantis dengan pelaku Force. Adegan intim dewasa konsensual cukup tersirat tanpa detail seksual eksplisit.

## Kontrak keluaran dan integrasi

Keluaran harus siap ditinjau untuk proyek Ren'Py yang sudah berjalan. Edit hanya narasi/dialog (dan bila perlu kata pada caption tanpa mengubah maksudnya). PERTAHANKAN nama/signature label, indentasi logis, semua return/jump/call, ID event, jumlah dan urutan opsi, kondisi host/lokasi/saldo/hasil ujian, percabangan, dan SEMUA statement mekanik yang sudah ada. Jangan menambah atau menghapus efek, flag, hook, waktu, uang, fungsi, karakter, label, init Python, screen, atau scheduler. Jangan mengganti nama variabel engine. Jangan menyalin blok hook konteks ke keluaran.

Baris pertama label kkscene tetap `call kk_scene_enter(...)` seperti kode acuan. Helper khusus boleh diawali guard yang sudah ada; jangan pindahkan/meniadakannya. Scene dengan menu 3/4 memakai struktur yang sudah ada dalam acuan (umumnya kk_family_menu untuk 3, _rows/kk_choice_panel/kk_record_choice untuk 4). Pengecualian menu bersyarat, 2/5 opsi, indeks numerik, dan helper bersama harus dipertahankan persis; jangan menormalkan menu jika itu mengubah kondisi atau mekanisme lama.

Narasi: `nar "..."`. Tokoh utama: koita/miyuki/nagisa/harumi/moeka/shiori/chiasa/yutaka (huruf kecil). Sistem: `sistem "..."` bila memang hadir. NPC: `"Nama NPC" "..."`. Jangan menghasilkan dialog tanpa pembicara. Satu statement dialog per baris fisik; tidak ada newline literal dalam kutip dialog; escape kutip internal dengan backslash sebelum kutip ganda. Jangan menampilkan statistik/ID/flag dalam dialog kecuali memang bagian ucapan Sistem yang relevan. Gunakan narasi orang kedua sesuai acuan; jangan tiba-tiba memberi pemain identitas atau ingatan baru.

Sebelum menjawab, periksa diam-diam: semua opsi dan makna A/B/C/D/E masih sama; seluruh statement mekanik dan syarat dipertahankan; pembicara benar; tidak ada hasil rute yang dipaksakan; masing-masing cabang hidup sebagai adegan. Keluarkan HANYA satu blok kode renpy berisi label target lengkap. Tanpa pengantar, analisis, ringkasan, elipsis pengganti bagian, komentar TODO atau janji melanjutkan.

## Label lengkap saat ini — tulis versi penggantinya

```renpy
label kkscene_Mi_D06:
    call kk_scene_enter("miyuki", "Rumah Sakit Tachibana · Lorong sepi")
    nar "Miyuki menunggu sampai lorong sepi sebelum memintamu tinggal. Ia menjelaskan kesalahan kecil yang tadi sudah selesai, lalu menanyakan apakah kau kecewa. Jawaban yang tidak terdengar cukup keras justru membuatnya gelisah."
    miyuki "Bilang saja aku bodoh. Kalau kamu yang mengatakannya, aku tahu harus menerima apa. Aku capek menunggu tanpa tahu kapan selesai."
    nar "Ia menatapmu dengan permintaan yang mengerikan justru karena terdengar begitu masuk akal baginya."
    python:
        _caps = ["Tolak dengan lembut; ia tidak pantas itu.", "Turuti permintaannya.", "Alihkan ke hal lain.", "Ajak ia menemui Sato Kyoko."]
        _rows = [(cap, Return(key), False) for key, cap in zip("ABCD", _caps)]
    call screen kk_choice_panel(_rows, "Tanggapi Miyuki")
    $ _key = _return
    $ kk_family_choice("Mi-D06", _key)
    if _key == "A":
        nar "Kau menolak merendahkannya, tetap tinggal ketika wajahnya berubah takut. Miyuki mengulang bahwa ia tidak keberatan, seolah sedang menawarkan syarat yang lebih mudah."
        miyuki "Kalau kamu nggak marah, bukan berarti kamu sudah nggak peduli?"
        nar "Kau menjawab pertanyaannya, tidak memenuhi permintaan yang melukainya. Ia terdiam lama. Menerima perhatian tanpa hukuman ternyata memerlukan keberanian yang belum ia punya seluruhnya."
    elif _key == "B":
        nar "Kau menuruti. Miyuki menunduk, lalu tampak lega ketika mendapatkan bentuk perhatian yang sudah ia pahami. Kelegaan itu tidak membuat apa yang baru terjadi menjadi sehat."
        miyuki "Terima kasih sudah jujur. Aku akan lebih baik."
        nar "Ia berterima kasih atas penghinaan. Sesudahnya ia lebih cepat mencari persetujuanmu, lebih sulit percaya pada keramahan yang tidak menuntut penebusan."
    elif _key == "C":
        nar "Kau mengalihkan topik ke makanan dan jadwal. Miyuki mengikuti, mengingat detail yang kausampaikan dengan perhatian berlebihan."
        miyuki "Baik. Jadi kita nggak membahasnya lagi?"
        nar "Ia tidak menanyakan karena sudah tenang. Ia sedang memastikan apakah pembicaraan yang belum selesai itu akan kembali pada saat yang tidak bisa ia duga."
    else:
        nar "Kau mengajaknya menemui Sato dan menunggu ia bersedia. Pada pertemuan itu, Miyuki mengulang permintaannya dengan malu yang hampir membuat kalimatnya tak terdengar."
        "Sato Kyoko" "Saat kamu meminta dimarahi, apa yang kamu harapkan berhenti sesudahnya? Kita bisa mulai dari situ."
        nar "Miyuki tidak langsung menjawab. Tetapi tidak seorang pun menghukumnya karena perlu waktu, dan itu menjadi pengalaman pertama yang bisa ia bawa pulang dari percakapan tersebut."
    $ kk_minutes(10)
    return
```

Sekarang tulis satu versi adegan yang selesai, mengikuti tugas tunggal dan batas di atas. Hanya blok kode pengganti.
