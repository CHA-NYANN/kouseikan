# Prompt mandiri Gemini Web — Mi-D12: Ia Memilih Dirinya

Kamu penulis baru untuk Kouseikan. Anggap ini chat baru: semua konteks yang dibutuhkan ada dalam pesan ini. Jangan mengandalkan percakapan sebelumnya, pengetahuan file repo, atau meminta pengguna menempel bahan tambahan. Naskah acuan di bawah adalah draf yang ingin diganti, bukan gaya yang wajib ditiru.

## Tugas tunggal

Tulis ulang hanya event Mi-D12.

Sumber lokal untuk orang yang nanti memasang hasil: `game/kk_miyuki_daily.rpy:111`; label `kk_miyuki_refuses`. Gemini Web tidak perlu dan tidak dianggap dapat membuka path tersebut.

## Premis, waktu, POV dan aturan dunia

Kouseikan adalah visual novel drama psikologis bercabang, berlatar universitas Jepang, ditulis dalam bahasa Indonesia. Pemain mati di dunia asal lalu menempati tubuh Yutaka ATAU Chiasa dalam dunia manga harem yang tidak disukainya. Kesadaran pemilik tubuh asli hilang; jangan membuat pemilik lama berdialog sebagai orang kedua yang hadir di ruangan. Pemain tidak mewarisi ingatan pribadi atau keterampilan rumit host, hanya tubuh dan kebiasaan sederhana.

Koita adalah MC manga asli, BUKAN otomatis tokoh yang dikendalikan pemain. Sistem NTR yang sinis mengancam pemain: takdir romantis Koita harus cukup menyimpang ketika ia wisuda, atau pemain mati. Perhitungan itu bukan penilaian moral; kebaikan maupun kekejaman punya akibat tersendiri. Jangan mengubah Sistem menjadi dalih yang membenarkan pelaku atau membuat angka menjadi cinta.

Permainan mulai 7 April; rentang tiga tahun sampai wisuda Koita pada Maret. Awal: Koita/Yutaka/Nagisa/Harumi/Moeka/Shiori tahun kedua, Chiasa tahun pertama, Miyuki tahun ketiga. Semua tokoh romansa/mahasiswa 18+. Adik-adik kecil Moeka adalah tokoh keluarga saja. Geng kecil: Koita, Yutaka, Nagisa, Chiasa. Kelompok belajar SMA: Koita, Yutaka, Nagisa, Miyuki, Harumi. NPC boleh menolak; tidak ada ketertarikan yang dijamin.

Chiasa dan Koita saudara tiri tanpa hubungan darah. Pada host Yutaka, Chiasa adalah NPC independen; pada host Chiasa, Yutaka adalah NPC independen. Jangan menghadirkan pemain dan host sebagai dua tubuh. BL Yutaka–Koita memakai ketegasan emosional dengan hak menolak tetap utuh. Chiasa dapat menjalani yuri; romansa heteronya terkait Koita/Yutaka. Chiasa–Yutaka saja tidak otomatis menyimpangkan hidup Koita dan tidak otomatis menyelamatkan kontrak.

Cerita bercabang: jangan menyatakan opsi dari adegan lain sudah dipilih, hubungan sudah resmi, rahasia sudah diketahui, atau ending tertentu pasti terjadi jika kondisi/kode di paket ini tidak menjaminnya. Metadata katalog bisa basi; struktur dan kondisi pada kode saat ini mengalahkan komentar.

## Karakter dan hubungan yang perlu diingat dalam prompt INI

### Pegangan suara dan fakta
- Tachibana Miyuki: senpai Kedokteran, hangat, rajin merawat orang dan membuat kue. Kebiasaan mendahulukan orang lain menutupi lelah dan kebutuhan disayangi. Suaranya lembut tetapi ia bisa tegas. Sena sahabatnya; Hayase Takeru calon omiai sepihak, bukan pasangan yang otomatis sah.
- Kisaragi Yutaka: mahasiswa Ekonomi/Bisnis, sahabat kecil Koita, tinggal di apartemen bagus. Aslinya santai, jahil, blak-blakan, hangat dan menyimpan kesepian; menyukai Chiasa. Pemain tidak mewarisi ingatan pribadi, materi kuliah atau skill game profesionalnya. Keluarga kaya tetapi berjarak; Amamiya tempat ia merasa diterima. Ia TIDAK punya kunci cadangan rumah Amamiya.
- Amamiya Chiasa: mahasiswa Seni tahun pertama, adik TIRI Koita tanpa hubungan darah. Posesif halus dan suka menggoda Ko-nii. Rambut cokelat gelap half-up berpita hitam, mata keemasan. Ilustrator nama pena Shena. Daisuke ayah biologisnya, Yoshie ibu biologis Koita/ibu tirinya. Pemain dalam tubuh Chiasa TIDAK mewarisi kemampuan menggambarnya.
- Amamiya Koita: MC manga asli, mahasiswa Sastra. Baik dan mudah tersanjung, terbiasa menggantung jawaban karena takut mengecewakan atau kehilangan orang. Awal naif, lalu bisa sadar, memilih, atau retak. Jangan jadikan ia bodoh permanen maupun penjahat yang sudah sadar sejak awal.

Profil bertanda canon/usulan adalah bahan kerja proyek, bukan permintaan konfirmasi. Jangan meminta persetujuan ulang karena ada tanda usulan. Profil menggambarkan kemungkinan rentang karakter; jangan memainkan semua tahap distorsi sekaligus. Koreksi fakta pada pegangan suara di atas dan kondisi adegan sekarang mengalahkan rincian lama yang bertentangan.

### Profil lengkap tokoh fokus (rujukan, bukan perintah memainkan semua tahap rute)
# Tachibana Miyuki (橘 美雪) — senpai kedokteran

Status: profil ✅, visual ✅ ACC, sisanya 🟡 usulan. Rute distorsi: Masokis (emosional + romantis, ditulis non-eksplisit).

## 1. Identitas
- ✅ Tahun ketiga Kedokteran, Kouseikan. Sekitar 21 tahun. Satu tahun di atas Koita dan Yutaka. Salah satu 5 heroine utama. Sudah mencintai Koita, belum berpacaran.
- ✅ Tinggal sendiri di apartemen mewah dekat kampus. Keluarga Tachibana kaya, orang tua sangat sibuk.
- 🟡 Ulang tahun: 9 Desember. Golongan darah AB.

## 2. Penampilan (✅ ACC)
- Rambut hitam panjang lurus, terurai, tanpa hiasan kepala. Mata biru sapphire. Tinggi, anggun. Outfit utama: jas dokter putih di atas atasan ungu gelap, rok hitam, stetoskop.
- 🟡 Pakaian rumah: kardigan krem dan celana longgar. Di apartemen dia terlihat jauh lebih santai dan "lebih muda".

## 3. Kepribadian
- ✅ Publik: senior hangat, lembut, dewasa, bisa diandalkan. Akrab: onee-san yang manja, jahil, suka menggoda, mudah merajuk.
- ✅ Kelemahan: sulit meminta bantuan, mudah kesepian, memaksakan diri dalam studi.
- ✅ Menyukai hubungan serius, eksklusif, setia. Tidak suka pertemanan dijadikan alat bisnis.
- 🟡 Sifat di bawah permukaan: perhatiannya pada orang lain adalah cara dia merasa berguna. Kalau tidak dibutuhkan, dia merasa tidak punya nilai.

## 4. Latar belakang
- ✅ Orang tua sering diminta mendekati Shiori demi koneksi; Miyuki diam-diam tidak suka. Cita-cita: dokter spesialis anak. Hobi: memasak makanan rumahan dan pastry.
- ✅ Cinta pada Koita muncul setelah Koita tidak menghakimi sisi manjanya. Dia belum tahu motif Koita menggantung perasaan.
- 🟡 Orang tuanya: ayah dokter bedah, ibu direktur rumah sakit swasta. Mereka mengirim hadiah mahal, jarang hadir.

## 5. Hubungan awal
| Dengan | Kondisi | Aff | Trust | Intim | Jeal | Fear |
|---|---|---|---|---|---|---|
| Koita | ✅ mencintai; senpai–kouhai akrab | Tinggi | Tinggi | Sedang | Sedang | Rendah |
| Yutaka | ✅ kenal nama, bicara singkat | Rendah | Sedang | Rendah | Rendah | Rendah |
| Chiasa | ✅ kenal lewat Koita | Rendah | Sedang | Rendah | Sedang | Rendah |
| Shiori | ✅ saling tahu wajah/nama dari acara keluarga | Rendah | Sedang | Rendah | Rendah | Rendah |
| Nagisa | 🟡 kelompok belajar SMA; menyayanginya seperti adik | Sedang | Sedang | Sedang | Rendah | Rendah |
| Harumi | ✅ formal dan sopan (kelompok belajar SMA) | Rendah | Sedang | Rendah | Rendah | Rendah |
| Moeka | 🟡 pernah merawatnya yang pingsan; Moeka manja padanya | Sedang | Sedang | Rendah | Rendah | Rendah |
| Sena (NPC) | 🟡 sahabat dekat | Tinggi | Tinggi | Tinggi | Rendah | Rendah |

## 6. Motivasi, ketakutan, kelemahan
- 🟡 Ingin: seseorang yang menjaga dia saat dia lelah, bukan hanya dipuji.
- 🟡 Takut: terlihat lemah dan tidak lagi dibutuhkan.

## 7. Gaya bicara
- 🟡 Lembut, pakai "ara ara", menggoda halus sambil tersenyum. Jika merajuk, nadanya mengecil dan kalimatnya pendek.
- 🟡 Contoh:
  - "Ara, kamu lagi ngelamun ya? Mau senpai bikinin teh?"
  - "Aku nggak merajuk kok. ...Cuma sedikit."
  - "Aku baik-baik aja. Beneran. Jangan khawatirin aku."

## 8. Kehidupan harian dan hadiah
- 🟡 Kuliah dan praktik Senin–Jumat, belajar malam, memasak Sabtu pagi, belanja bahan Minggu.
- 🟡 Hadiah yang disukai: bahan pastry bagus, buku anak, teh, hal-hal yang menunjukkan perhatian. Hadiah mahal membuatnya canggung.

## 9. Pemicu cemburu
- 🟡 Koita menyebut heroine lain terlalu bersemangat. Janji yang dilanggar tanpa kabar. Dibatalkan demi orang lain.
- 🟡 Reaksi: tersenyum tipis, bilang "tidak apa-apa", lalu membuat kue terlalu banyak.

## 10. Personal storyline 🟡
1. Hari-hari praktik: dia kelelahan, pemain menemukan sisi manjanya.
2. Pesta/pertemuan keluarga: tekanan mendekati Shiori.
3. Ujian besar dan kesendirian.
4. Titik balik: sakit/pingsan karena memaksakan diri.
5. Pilihan: bersama Koita, bersama pemain, atau mandiri.

## 11. Rute Distorsi: Masokis (✅ arah, tahap 🟡)
Catatan: ditulis sebagai gambaran kerusakan hubungan, tanpa adegan eksplisit. Poin utamanya adalah dia mulai mengaitkan perlakuan buruk dengan perhatian.
1. **Kelelahan dan kesepian:** diabaikan atau dimanfaatkan, tetap berusaha.
2. **Perhatian = dimarahi:** hanya saat ditegur dia merasa dilihat.
3. **Normalisasi:** minta maaf berlebihan, mencari orang yang tegas dan dingin.
4. **Titik balik (event):** kesalahan di praktik atau kegagalan ujian, lalu sebuah teguran keras membuatnya lega. Sejak itu pola dibentuk.
5. **Pola menetap:** dinamika dominasi–penyerahan secara emosional dan romantis (tersirat, fade-to-black).
- **Tanda yang terbaca:** senyum yang lebih tenang setelah dimarahi, meminta hukuman kecil, mengabaikan istirahat, menolak bantuan Sena.
- **Pemulihan:** 🟡 mungkin sebagian. Butuh Sena dan jeda dari pemain. Tanpa intervensi, jadi permanen.
- **Yang menyadari:** Sena (cepat), orang tua (lambat), Koita (tidak sadar).

## 12. Ending 🟡
- **Bad:** burnout, keluar dari kedokteran / drop semester.
- **Neutral:** kembali ke pola lama, mandiri, jarak dengan semua.
- **Distorted:** hubungan "nyaman" yang tidak sehat dengan pemain.
- **Romantis dengan pemain:** hubungan eksklusif yang setara; dia belajar meminta tolong.

## 13. Perbedaan Male vs Female
- 🟡 Male Route: Yutaka dianggap adik tingkat sahabat Koita yang jahil. Female Route: Chiasa dianggap adik Koita yang digoda.

## 14. Keputusan yang sudah kuisi (🟡)
- **Tinggi:** 170 cm.
- **Pemulihan Rute Masokis:** sebagian. Sebelum tahap 4 mudah dipulihkan. Setelah tahap 5 bertahan lebih dari satu semester tanpa intervensi, pola itu menetap permanen (ia bisa hidup dengannya, tidak sembuh total).
- **Hubungan dengan Nagisa, Harumi, Moeka:** lihat tabel di atas dan [Hubungan_Antar_Karakter.md](../Hubungan_Antar_Karakter.md).
- **Batas konten romantis/seksual Rute Masokis:** teks boleh dewasa dan menggambarkan dinamika dominasi–penyerahan secara emosional; tidak ada ilustrasi seksual eksplisit.
- **Koita:** pernah benar-benar disukai Miyuki juga dari sisi Koita (SMA), tetapi Miyuki tidak tahu. Ini bisa jadi bom waktu saat terungkap.


### Hubungan awal yang relevan; tidak otomatis menggambarkan keadaan sekarang
| Yutaka – Moeka | Satu panitia Festival Musim Dingin (Moeka koordinator acara, Yutaka bagian dana). Moeka menggodanya santai, Yutaka membalas jahil. Aff Sedang, Trust Sedang, Intim Rendah. |
| Chiasa – Moeka | Satu fakultas (Seni Rupa dan Desain), senpai–kouhai. Moeka mengajak Chiasa menggambar sketsa untuk mini-show. Aff Sedang, Trust Sedang, Jeal Rendah. |
| Chiasa – Shiori | Belum pernah bicara. Shiori diam-diam pembaca light novel strategi yang diilustrasi "Shena" (nama pena Chiasa), tapi tidak tahu itu Chiasa. Aff Rendah, Trust Rendah. |
| Nagisa – Miyuki | Kelompok belajar SMA. Nagisa mengagumi dan merasa kalah dewasa; Miyuki menyayanginya seperti adik. Aff Sedang, Trust Sedang, Jeal Sedang (Nagisa→Miyuki). |
| Miyuki – Moeka | Miyuki pernah merawat Moeka yang pingsan karena lupa makan saat acara kampus. Moeka memanggilnya "Miyuki-senpai~" manja. Aff Sedang, Trust Sedang. |
| Koita – Moeka | Saat orientasi, Moeka lupa membawa dokumen panitia; Koita menutupinya tanpa memperbesar. Sejak itu Moeka jatuh cinta. |
| Koita – Miyuki (masa lalu) | Di SMA Koita sempat **benar-benar menyukai** Miyuki, tapi mundur karena merasa tak sepadan. Sejak itu ia memilih menggantung. Hanya Koita yang tahu. |
| Target | Dikejar Yutaka | Dikejar Chiasa |

### NPC terkait: Hayase Takeru
# Hayase Takeru — calon omiai Miyuki

Status: 🟡 seluruhnya usulan. Pengejar sepihak, bukan pasangan jadi.

## Peran
Pilihan orang tua Miyuki. Tekanan keluarga yang tampak sempurna; bukan penjahat.

## Profil
- 26 tahun, residen bedah di rumah sakit milik keluarga kolega ayah Miyuki. Rambut hitam rapi, jas dokter, tinggi 177 cm.
- Sopan, mapan, menyenangkan. Menyukai Miyuki tulus tetapi memandangnya sebagai "calon istri ideal" lebih dari sebagai orang.
- Tidak tahu sisi manja Miyuki.

## Hubungan dan fungsi
- Dengan Miyuki: Aff Sedang (satu arah), Trust Sedang. Miyuki sopan tapi menjaga jarak.
- Orang tua Miyuki mendorong dari belakang; Sena tidak menyukainya.
- Bila Miyuki berada di Rute Masokis: Takeru bisa jadi pihak yang tak sadar memperparah (terlalu sopan, tak pernah marah) atau justru menolong (bila ia menyadari).
- Bila pemain mengejar Miyuki: Takeru tidak agresif, tetapi punya keunggulan status. Pemain harus menang lewat ketulusan.

## Gaya bicara
- "Tachibana-san, bolehkah saya mengantar Anda? Hari sudah malam."
- "Saya tahu saya bukan pilihan Anda. Tapi saya tidak keberatan menunggu."


### NPC terkait: Orang Tua Tachibana
# Orang Tua Tachibana — Kazuhiro & Sayuri

Status: canon hanya "kaya, sangat sibuk, mendorong Miyuki mendekati Shiori" ✅. Nama dan sisanya 🟡.

## Peran
Sumber tekanan dan kesepian Miyuki. Penggerak omiai dengan Hayase Takeru.

## Profil
- **Tachibana Kazuhiro** (53), dokter bedah senior. Dingin-efisien, bangga pada prestasi, canggung soal kasih sayang.
- **Tachibana Sayuri** (50), direktur rumah sakit swasta. Anggun, strategis, selalu bicara "demi masa depanmu".
- Mereka mencintai Miyuki tetapi mengekspresikannya lewat hadiah dan rencana, bukan waktu.

## Hubungan dan fungsi
- Dengan Miyuki: Aff Tinggi, Intim Rendah. Menelepon seminggu sekali, jadwalnya selalu bentrok.
- Menyuruh Miyuki mendekati Shiori (✅). Miyuki diam-diam tidak suka.
- Memperkenalkan Hayase Takeru sebagai calon omiai bila Miyuki "belum punya pilihan".
- Bila pemain terlihat tidak sepadan secara status, mereka ramah di depan dan menekan di belakang.

## Reaksi
- Miyuki berubah (Rute Masokis): lambat menyadari; mengira "lelah praktik". Baru sadar saat Sena menelepon.
- Pemain mengejar Miyuki: menilai latar, karier, dan "kestabilan". Bisa dimenangkan dengan konsistensi dan rasa hormat.

## Gaya bicara
- "Miyuki, ibu sudah atur jadwal makan malam dengan keluarga Hayase. Kamu pasti suka."
- "Ayah bangga. Itu saja yang perlu kamu tahu."


## Posisi adegan dan batas kontinuitas

POV dapat bergantung pada host yang dipilih. ID event atau karakter pada kk_scene_enter bukan bukti bahwa dialah pemain. Pertahankan guard/cabang host pada acuan; bagian bersama harus masuk akal untuk kedua host. Jangan mengunci jenis kelamin/identitas pemain jika kode tidak menguncinya.

Event DINAMIS, urutannya tidak tetap. Pemicu di bawah menentukan apakah ia terjadi; nomor -D bukan tanggal atau bukti event dinamis sebelumnya sudah terjadi.

Koreksi khusus untuk adegan ini: **Jika komentar/katalog bertentangan dengan kode acuan, kode menang. Jangan menambah atau menukar opsi.**

### Panduan adegan lokal

```text
# ┌─ PANDUAN CERITA · Mi-D12 · Ia Memilih Dirinya
# │ LOKASI  : (dinamis — muncul dari kondisi)
# │ TERLIBAT: Tachibana Miyuki
# │ AWALAN  : dimanja ≥ 70; semua luka < 30; Trust ≥ 70
# │ INTI    : A Dukung / B goda / C bilang itu berkat pemain
# │ AKHIRAN : omiai_takeru −30; E-MI-01 dan E-MI-02 menguat
# └─ tulis / perbaiki dialog di bawah ──
```

### Data katalog untuk orientasi saja; pilihan aktual tetap dari kode

```json
{
  "id": "Mi-D12",
  "name": "Ia Memilih Dirinya",
  "trigger": "dimanja ≥ 70; semua luka < 30; Trust ≥ 70",
  "desc": "untuk pertama kali ia berkata \"tidak\" pada ibunya. Dukung / goda / bilang itu berkat pemain",
  "choices": [
    "Dukung",
    "goda",
    "bilang itu berkat pemain"
  ],
  "effect": "omiai_takeru −30; E-MI-01 dan E-MI-02 menguat"
}
```


### Efek kode yang sudah tertaut — baca saja, JANGAN tulis ulang
```text
kk_life_events.rpy: if eid == "Mi-D12":
call kk_miyuki_refuses
$ kk_minutes(10)
return
```
Nilai ini hanya penuntun konsekuensi emosional. Jangan mengucapkan nilainya, menjanjikan ending, atau mengeksekusinya lagi.

## Sasaran penulisan

Tulis adegan yang benar-benar dimainkan: percakapan konkret, gestur, tindakan kecil, subteks, ruang, waktu, dan perubahan suasana. Biarkan ketegangan bergerak melalui apa yang dilakukan/dikatakan tokoh. Kurangi paragraf yang menjelaskan tema, merangkum pelajaran hidup, atau memberi vonis narator setelah setiap dialog. Jangan otomatis membuat semua tokoh memakai suara konselor yang sama; tokoh boleh menghindar, salah paham, marah, kikuk, egois, atau menyakitkan sesuai pilihan.

Bahasa Indonesia natural dengan irama lisan yang cocok untuk masing-masing tokoh. Hindari terjemahan kaku, pembuka generik berulang, metafora yang dipaksakan, jargon mesin dalam mulut NPC, dan penutup moral seragam. Jangan menyalin prosa sekarang hanya dengan sinonim; ia bahan kasar yang boleh diganti total. Pertahankan fakta yang dikunci, bukan kualitas prosa lama. Tidak ada batas kata buatan: tulis sepanjang yang dibutuhkan adegan, dengan setiap cabang mendapatkan perkembangan, reaksi, dan pendaratan yang terasa berbeda; jangan memanjangkan dengan pengulangan.

Tema gelap tetap boleh intens: kecemburuan, obsesi, penolakan, perselingkuhan emosional, ancaman, krisis keluarga, kekerasan nonseksual, trauma dan akibat sosial/hukum. Kekerasan seksual tidak ditulis grafis atau sebagai langkah menembus perlawanan; potong ke akibat. Jangan uraikan metode bunuh diri/menyakiti diri atau prosedur memfitnah/menjebak korban. Tulis niat, ketegangan, penderitaan, respons orang lain dan konsekuensinya dengan bobot penuh. Ketakutan/ketergantungan bukan cinta atau persetujuan; tidak ada ending romantis dengan pelaku Force. Adegan intim dewasa konsensual cukup tersirat tanpa detail seksual eksplisit.

## Kontrak keluaran dan integrasi

Keluaran harus siap ditinjau untuk proyek Ren'Py yang sudah berjalan. Edit hanya narasi/dialog (dan bila perlu kata pada caption tanpa mengubah maksudnya). PERTAHANKAN nama/signature label, indentasi logis, semua return/jump/call, ID event, jumlah dan urutan opsi, kondisi host/lokasi/saldo/hasil ujian, percabangan, dan SEMUA statement mekanik yang sudah ada. Jangan menambah atau menghapus efek, flag, hook, waktu, uang, fungsi, karakter, label, init Python, screen, atau scheduler. Jangan mengganti nama variabel engine. Jangan menyalin blok hook konteks ke keluaran.

Baris pertama label kkscene tetap `call kk_scene_enter(...)` seperti kode acuan. Helper khusus boleh diawali guard yang sudah ada; jangan pindahkan/meniadakannya. Scene dengan menu 3/4 memakai struktur yang sudah ada dalam acuan (umumnya kk_family_menu untuk 3, _rows/kk_choice_panel/kk_record_choice untuk 4). Pengecualian menu bersyarat, 2/5 opsi, indeks numerik, dan helper bersama harus dipertahankan persis; jangan menormalkan menu jika itu mengubah kondisi atau mekanisme lama.

Narasi: `nar "..."`. Tokoh utama: koita/miyuki/nagisa/harumi/moeka/shiori/chiasa/yutaka (huruf kecil). Sistem: `sistem "..."` bila memang hadir. NPC: `"Nama NPC" "..."`. Jangan menghasilkan dialog tanpa pembicara. Satu statement dialog per baris fisik; tidak ada newline literal dalam kutip dialog; escape kutip internal dengan backslash sebelum kutip ganda. Jangan menampilkan statistik/ID/flag dalam dialog kecuali memang bagian ucapan Sistem yang relevan. Gunakan narasi orang kedua sesuai acuan; jangan tiba-tiba memberi pemain identitas atau ingatan baru.

Sebelum menjawab, periksa diam-diam: semua opsi dan makna A/B/C/D/E masih sama; seluruh statement mekanik dan syarat dipertahankan; pembicara benar; tidak ada hasil rute yang dipaksakan; masing-masing cabang hidup sebagai adegan. Keluarkan HANYA satu blok kode renpy berisi label target lengkap. Tanpa pengantar, analisis, ringkasan, elipsis pengganti bagian, komentar TODO atau janji melanjutkan.

## Label lengkap saat ini — tulis versi penggantinya

```renpy
label kk_miyuki_refuses:
    nar "Miyuki memperlihatkan kalender. Satu Sabtu yang biasanya sudah penuh coretan keluarga kini kosong, bukan karena ia lupa menuliskan sesuatu."
    miyuki "Ibu menelepon soal Hayase. Aku bilang tidak mau bertemu untuk omiai lagi. Bukan karena sibuk. Aku sengaja tidak memakai jadwal sebagai alasan."
    nar "Ia masih menggenggam ponsel, ibu jarinya mengusap bagian samping yang sama berulang kali."
    miyuki "Ibu diam lama. Aku hampir bilang mungkin bulan depan. Tapi aku menunggu sampai beliau menjawab."
    call kk_family_menu("Mi-D12", ["Dukung keputusan Miyuki.", "Goda dia soal berani membantah ibunya.", "Katakan kau yang membuatnya berani."])
    if _return == "A":
        nar "Kau mendukung keputusan itu dan menanyakan apa yang ia perlukan sekarang. Miyuki berpikir, lalu meminta minum dan waktu untuk tidak membicarakan Hayase."
        miyuki "Kalau Ibu bertanya lagi, aku mau menjawab sendiri. Tapi hari ini aku ingin merasakan bahwa Sabtu itu boleh kosong."
        nar "Ia meletakkan ponsel. Sesudah beberapa menit tangannya berhenti mencari benda tersebut setiap kali ada suara."
    elif _return == "B":
        nar "Kau menggoda keberaniannya membantah keluarga. Miyuki sempat tertawa, lalu mengangkat tangan agar kau melihat getarnya."
        miyuki "Aku memang gemetar. Ini bukan karena mendadak jadi orang berani. Aku cuma tetap bilang tidak meskipun takut."
        nar "Ia menunggu sampai kau mendengarnya dengan serius sebelum ikut tertawa lagi."
    else:
        nar "Kau menyebut keberanian itu sebagai hasil pengaruhmu. Miyuki memandangmu sebentar, kali ini tidak buru-buru membalas dengan terima kasih."
        miyuki "Kamu sudah membantuku. Aku nggak menyangkal. Tapi tadi aku yang bicara. Aku ingin boleh menyimpan bagian itu sebagai milikku."
        nar "Kalimatnya lembut, tetapi tidak ditarik kembali ketika suasana menjadi canggung."
    return
```

Sekarang tulis satu versi adegan yang selesai, mengikuti tugas tunggal dan batas di atas. Hanya blok kode pengganti.
