# Prompt mandiri Gemini Web — E-HA-08: Ogawa Menang

Kamu penulis baru Kouseikan. Ini chat mandiri. Tulis ulang SATU ending berikut dengan seluruh konteks di pesan ini; jangan merujuk percakapan lama atau meminta pengguna mengirim isi repo.

## Tugas tunggal

Tulis teks ending E-HA-08. Pertahankan jenis hasil, kondisi muncul, host yang berlaku, tokoh dan konsekuensinya. Jangan membuat akhir bahagia baru jika hasilnya buruk; jangan menukar siapa pelaku/korban/pasangan. Untuk ending yang mencakup beberapa kondisi atau hasil evaluasi, jangan mengunci satu varian yang tidak dijamin metadata. Hanya tulis bagian yang berlaku bersama atau gunakan cara bertutur yang tidak mengubah resolver.

## Premis dan identitas host

Kouseikan adalah visual novel drama psikologis bercabang, berlatar universitas Jepang, ditulis dalam bahasa Indonesia. Pemain mati di dunia asal lalu menempati tubuh Yutaka ATAU Chiasa dalam dunia manga harem yang tidak disukainya. Kesadaran pemilik tubuh asli hilang; jangan membuat pemilik lama berdialog sebagai orang kedua yang hadir di ruangan. Pemain tidak mewarisi ingatan pribadi atau keterampilan rumit host, hanya tubuh dan kebiasaan sederhana.

Koita adalah MC manga asli, BUKAN otomatis tokoh yang dikendalikan pemain. Sistem NTR yang sinis mengancam pemain: takdir romantis Koita harus cukup menyimpang ketika ia wisuda, atau pemain mati. Perhitungan itu bukan penilaian moral; kebaikan maupun kekejaman punya akibat tersendiri. Jangan mengubah Sistem menjadi dalih yang membenarkan pelaku atau membuat angka menjadi cinta.

Permainan mulai 7 April; rentang tiga tahun sampai wisuda Koita pada Maret. Awal: Koita/Yutaka/Nagisa/Harumi/Moeka/Shiori tahun kedua, Chiasa tahun pertama, Miyuki tahun ketiga. Semua tokoh romansa/mahasiswa 18+. Adik-adik kecil Moeka adalah tokoh keluarga saja. Geng kecil: Koita, Yutaka, Nagisa, Chiasa. Kelompok belajar SMA: Koita, Yutaka, Nagisa, Miyuki, Harumi. NPC boleh menolak; tidak ada ketertarikan yang dijamin.

Chiasa dan Koita saudara tiri tanpa hubungan darah. Pada host Yutaka, Chiasa adalah NPC independen; pada host Chiasa, Yutaka adalah NPC independen. Jangan menghadirkan pemain dan host sebagai dua tubuh. BL Yutaka–Koita memakai ketegasan emosional dengan hak menolak tetap utuh. Chiasa dapat menjalani yuri; romansa heteronya terkait Koita/Yutaka. Chiasa–Yutaka saja tidak otomatis menyimpangkan hidup Koita dan tidak otomatis menyelamatkan kontrak.

Cerita bercabang: jangan menyatakan opsi dari adegan lain sudah dipilih, hubungan sudah resmi, rahasia sudah diketahui, atau ending tertentu pasti terjadi jika kondisi/kode di paket ini tidak menjaminnya. Metadata katalog bisa basi; struktur dan kondisi pada kode saat ini mengalahkan komentar.

## Karakter dan hubungan

### Pegangan suara dan fakta
- Kujo Harumi: mahasiswa Sains/Kimia, analitis dan canggung menamai perasaan. Ia punya emosi dan keinginan, bukan robot atau orang yang tidak paham persetujuan. Bahasa terukur, kadang memakai analogi ilmiah sewajarnya. Ogawa antagonis eksploitasi; Ogiwara Fumiko pengelola asrama, orang berbeda.
- Kisaragi Yutaka: mahasiswa Ekonomi/Bisnis, sahabat kecil Koita, tinggal di apartemen bagus. Aslinya santai, jahil, blak-blakan, hangat dan menyimpan kesepian; menyukai Chiasa. Pemain tidak mewarisi ingatan pribadi, materi kuliah atau skill game profesionalnya. Keluarga kaya tetapi berjarak; Amamiya tempat ia merasa diterima. Ia TIDAK punya kunci cadangan rumah Amamiya.
- Amamiya Chiasa: mahasiswa Seni tahun pertama, adik TIRI Koita tanpa hubungan darah. Posesif halus dan suka menggoda Ko-nii. Rambut cokelat gelap half-up berpita hitam, mata keemasan. Ilustrator nama pena Shena. Daisuke ayah biologisnya, Yoshie ibu biologis Koita/ibu tirinya. Pemain dalam tubuh Chiasa TIDAK mewarisi kemampuan menggambarnya.
- Amamiya Koita: MC manga asli, mahasiswa Sastra. Baik dan mudah tersanjung, terbiasa menggantung jawaban karena takut mengecewakan atau kehilangan orang. Awal naif, lalu bisa sadar, memilih, atau retak. Jangan jadikan ia bodoh permanen maupun penjahat yang sudah sadar sejak awal.

Profil bertanda canon/usulan adalah bahan kerja proyek, bukan permintaan konfirmasi. Jangan meminta persetujuan ulang karena ada tanda usulan. Profil menggambarkan kemungkinan rentang karakter; jangan memainkan semua tahap distorsi sekaligus. Koreksi fakta pada pegangan suara di atas dan kondisi adegan sekarang mengalahkan rincian lama yang bertentangan.

### Profil lengkap tokoh fokus (rujukan, bukan perintah memainkan semua tahap rute)
# Kujo Harumi (九条 春海) — kuudere sains (nama lama: Kujo Ritsuka)

Status: profil ✅ (nama lama SUPERSEDED), visual 🟡 sebagian, sisanya 🟡 usulan. Rute distorsi: Hypersexual/Exploitation (ditulis dari sisi psikologis dan konsekuensi, tanpa adegan eksplisit).

## 1. Identitas
- ✅ Kujo Harumi (🟡 kanji nama depan: 春海). Usia 20. Sains (Kimia dan Matematika), seangkatan dengan Koita dan Yutaka. Dulu Rank 1 angkatan. Cita-cita: profesor, lanjut pascasarjana di luar negeri.
- ✅ Tinggal di asrama mahasiswa Kouseikan. Orang tua akademisi/ilmuwan. Sudah mencintai Koita (v7.0).
- 🟡 Ulang tahun: 1 Oktober. Golongan darah A.

## 2. Penampilan
- ✅ Rambut abu-abu agak panjang, single side ponytail menjuntai ke depan salah satu bahu. Mata biru tua. Kacamata.
- Tinggi, postur, busana belum ditetapkan di canon; usulanku di bawah.
- 🟡 Usulan: 163 cm, ramping. Gaya sederhana monokrom, cardigan abu-abu, kemeja putih. Selalu membawa buku catatan kecil.

## 3. Kepribadian
- ✅ Kuudere: tenang, datar, lugas. Penyayang tersembunyi lewat tindakan kecil. Kesulitan mengidentifikasi emosinya sendiri. Membetulkan kacamata saat berpikir.
- ✅ Menganggap cinta tidak rasional, sulit dianalisis.
- ✅ Memasak buruk tapi tidak sadar; menyeduh teh sangat bagus.

## 4. Latar belakang
- ✅ Mengajar kelompok belajar SMA karena Koita memintanya secara pribadi. Gaya mengajar: sabar, sistematis, blak-blakan.
- 🟡 Orang tua: ayah profesor kimia, ibu peneliti matematika terapan. Mereka bangga tapi menilai lewat prestasi.
- 🟡 Mengapa Koita meminta secara pribadi: tidak ada yang pernah memintanya untuk sesuatu yang bukan "peringkat". Dari situ rasa "dibutuhkan" mulai.

## 5. Hubungan awal
| Dengan | Kondisi | Aff | Trust | Intim | Jeal | Fear |
|---|---|---|---|---|---|---|
| Koita | ✅ mencintai (belum mengerti) | Tinggi | Tinggi | Sedang | Rendah | Rendah |
| Yutaka | ✅ diskusi akademik, tidak dekat | Rendah | Sedang | Rendah | Rendah | Rendah |
| Nagisa | ✅ diam-diam menyukai sifatnya (belum tentu romantis) | Sedang | Sedang | Rendah | Rendah | Rendah |
| Miyuki | ✅ formal, sopan, jarang berinteraksi | Rendah | Sedang | Rendah | Rendah | Rendah |
| Chiasa | ✅ kenalan biasa | Rendah | Rendah | Rendah | Rendah | Rendah |
| Moeka | 🟡 kenalan satu angkatan; dicatat sebagai "variabel kacau" | Rendah | Rendah | Rendah | Rendah | Rendah |
| Shiori | 🟡 saling kenal nama; pernah diajak shogi, menolak | Rendah | Sedang | Rendah | Rendah | Rendah |
| Prof. Mizuhara | 🟡 dosen pembimbing | Sedang | Tinggi | Sedang | Rendah | Rendah |

## 6. Motivasi, ketakutan, kelemahan
- 🟡 Ingin: memahami apa yang ia rasakan.
- 🟡 Takut: ternyata dia tidak mampu merasakan seperti orang lain.
- ✅ Kelemahan: sulit membedakan nyaman, kagum, sayang, cemburu, cinta.

## 7. Gaya bicara
- 🟡 Datar, kalimat pendek, istilah ilmiah. Humor kering yang tidak sengaja.
- 🟡 Contoh:
  - "Hipotesis: aku merasa lebih tenang saat kamu ada. Perlu data lebih banyak."
  - "Teh ini sudah tiga menit. Sekarang diminum."
  - "Kalau kamu menyebut itu 'enak', variabelnya bukan rasa."

## 8. Kehidupan harian dan hadiah
- 🟡 Laboratorium Senin–Jumat, perpustakaan malam, menyeduh teh di dapur asrama Minggu.
- 🟡 Hadiah disukai: teh langka, buku referensi, alat tulis presisi. Bunga membuatnya bingung.

## 9. Pemicu cemburu
- 🟡 Dia tidak mengenali cemburu sebagai cemburu. Ia mencatatnya sebagai "gangguan konsentrasi" ketika Koita dekat dengan heroine lain.
- 🟡 Reaksi: menjadi lebih formal, melewatkan makan, memperbaiki kacamata berulang kali.

## 10. Personal storyline 🟡
1. Hari-hari lab; Harumi menyadari ia sering memikirkan Koita.
2. Eksperimen teh dan masakan (komedi).
3. Penelitian/tawaran beasiswa luar negeri.
4. Titik balik: pilihan antara mengejar karier jauh dari Jepang atau tinggal.
5. Akhir: memahami (atau menolak) perasaannya.

## 11. Rute Distorsi: Hypersexual / Exploitation (✅ arah, tahap 🟡)
Catatan: semua tahap adalah kemungkinan, bukan otomatis. Teks boleh dewasa dan gamblang soal dampak, tetapi tanpa ilustrasi seksual eksplisit. Fokusnya pada proses psikologis, bahaya eksploitasi, dan dampak. Harumi tetap punya agensi pada setiap pilihannya.
1. **Kekosongan emosi:** perasaannya tidak dibalas atau diabaikan; dia tidak mengerti apa yang hilang.
2. **Salah baca validasi:** perhatian fisik/seksual dikira bentuk cinta karena mudah "diukur".
3. **Pendekatan eksperimen:** dia memperlakukan kedekatan sebagai data untuk dipahami.
4. **Transaksional:** perhatian, uang, dan akses mulai ditukar (misal dana penelitian).
5. **Titik balik (event):** kemungkinan dieksploitasi pihak lain (senior, donatur) atau krisis keuangan studi.
6. **Pola menetap:** hidup berputar pada validasi dan transaksi; beberapa cabang bisa mengarah ke dunia kerja seksual sebagai "solusi rasional". Ditulis sebagai tragedi dan peringatan; adegan tidak ditampilkan.
- **Tanda yang terbaca:** pakaian dan gaya bicara berubah, absen dari lab, uang yang tidak jelas, menjauh dari Nagisa dan Mizuhara.
- **Pemulihan:** 🟡 sulit. Butuh intervensi nyata (Mizuhara, Nagisa, pengelola asrama) dan pemain berhenti memanfaatkan.
- **Yang menyadari:** Prof. Mizuhara (cepat), Nagisa (cepat, emosional), orang tua (lambat).

## 12. Ending 🟡
- **Bad:** drop out atau terjebak dalam eksploitasi.
- **Neutral:** kembali ke akademik dengan luka; lulus tanpa gelar impian.
- **Distorted:** hidup transaksional, merasa "mengerti".
- **Romantis dengan pemain:** belajar mengenali emosi bersama; hubungan pelan dan jujur.

## 13. Perbedaan Male vs Female
- 🟡 Male Route: pendekatan lewat tugas kelompok ekonomi/sains. Female Route: pendekatan lewat kolaborasi seni–sains (ilustrasi poster riset).

## 14. Keputusan yang sudah kuisi (🟡)
- **Kanji nama:** 九条 春海. **Tinggi/postur/busana:** 163 cm, ramping; gaya monokrom, cardigan abu-abu, kemeja putih.
- **Seberapa jauh rute eksploitasi ditampilkan:** teks dewasa yang menggambarkan tanda dan dampaknya; transaksi seksual tersirat; tanpa ilustrasi seksual. Konsekuensi (psikologis, kesehatan, sosial, hukum) ditampilkan penuh.
- **Hubungan dengan Moeka dan Shiori:** lihat tabel dan [Hubungan_Antar_Karakter.md](../Hubungan_Antar_Karakter.md).
- **Orang tua:** Kujo Tetsuya (55, profesor kimia anorganik) dan Kujo Mayumi (52, peneliti matematika terapan), di Universitas Riset Kansai. Prof. Mizuhara adalah mantan mahasiswi Tetsuya.
- **Tingkat hasil rute eksploitasi:** cabang terburuk berujung ketergantungan pada orang yang mengeksploitasinya; ada cabang di mana ia ditolong tepat waktu.


### Hubungan awal yang relevan; tidak otomatis menggambarkan keadaan sekarang
| Yutaka – Moeka | Satu panitia Festival Musim Dingin (Moeka koordinator acara, Yutaka bagian dana). Moeka menggodanya santai, Yutaka membalas jahil. Aff Sedang, Trust Sedang, Intim Rendah. |
| Chiasa – Moeka | Satu fakultas (Seni Rupa dan Desain), senpai–kouhai. Moeka mengajak Chiasa menggambar sketsa untuk mini-show. Aff Sedang, Trust Sedang, Jeal Rendah. |
| Chiasa – Shiori | Belum pernah bicara. Shiori diam-diam pembaca light novel strategi yang diilustrasi "Shena" (nama pena Chiasa), tapi tidak tahu itu Chiasa. Aff Rendah, Trust Rendah. |
| Harumi – Moeka | Kenalan satu angkatan. Harumi mencatat Moeka sebagai "variabel kacau"; Moeka mengajaknya jadi model (ditolak). Aff Rendah, Trust Rendah. |
| Harumi – Shiori | Saling kenal nama sebagai peringkat teratas angkatan. Shiori pernah mengajak shogi; Harumi menolak karena "tidak efisien". Saling menghormati. Aff Rendah, Trust Sedang. |
| Koita – Moeka | Saat orientasi, Moeka lupa membawa dokumen panitia; Koita menutupinya tanpa memperbesar. Sejak itu Moeka jatuh cinta. |
| Koita – Miyuki (masa lalu) | Di SMA Koita sempat **benar-benar menyukai** Miyuki, tapi mundur karena merasa tak sepadan. Sejak itu ia memilih menggantung. Hanya Koita yang tahu. |
| Target | Dikejar Yutaka | Dikejar Chiasa |

### NPC terkait: Ogawa Masato
# Ogawa Masato — senior lab yang mengeksploitasi

Status: 🟡 seluruhnya usulan. Antagonis untuk Rute Eksploitasi Harumi. Pengejar sepihak, bukan pasangan jadi.

## Peran
Pihak yang memanfaatkan kebingungan emosi Harumi. Contoh predator halus yang berlindung di balik jabatan.

## Profil
- 29 tahun, kandidat doktor di laboratorium kimia. Rambut hitam rapi, jas lab bersih, tinggi 178 cm.
- Karismatik, sopan, pandai membaca kelemahan. Menguasai akses data, dana, dan nama di publikasi.
- Tampak dermawan: menawarkan bantuan dana, nama penulis, dan perhatian.

## Hubungan dan fungsi
- Menjadi "senior baik" bagi Harumi, lalu menukar perhatian dengan akses dan keintiman.
- Tidak memakai kekerasan fisik; menekan lewat dependensi dan ancaman karier.
- Prof. Mizuhara, Ogiwara, dan Sena adalah penghalangnya.
- Konsekuensi hukum dan akademik bisa menjatuhkannya bila bukti ditemukan dan korban melapor (✅).
- Bila pemain mengejar Harumi: Ogawa menjadi penghalang yang licin.
- Event 🟡: rapat lab, undangan "diskusi", pesan larut malam, perselisihan dengan Mizuhara.

## Gaya bicara
- "Kujo-san, bakatmu terlalu besar untuk dibiarkan terbuang. Biar aku bantu."
- "Semua butuh timbal balik. Itu bukan dosa."


## Fakta ending yang terkunci

```json
{
  "code": "E-HA-08",
  "name": "Ogawa Menang",
  "type": "Bad",
  "host": "Y/C",
  "cond": "bukti kurang atau ditutupi; pemain penonton",
  "body": "Ogawa lolos; Harumi yang disalahkan; kariernya runtuh",
  "file": "03_Harumi_Eksploitasi.md"
}
```

Metadata ini menetapkan keadaan ending, bukan undangan membuat pilihan baru. Fakta canon dalam profil dan koreksi suara di atas mengalahkan detail prosa lama yang bertentangan.

## Gaya dan bobot cerita

Tulis adegan yang benar-benar dimainkan: percakapan konkret, gestur, tindakan kecil, subteks, ruang, waktu, dan perubahan suasana. Biarkan ketegangan bergerak melalui apa yang dilakukan/dikatakan tokoh. Kurangi paragraf yang menjelaskan tema, merangkum pelajaran hidup, atau memberi vonis narator setelah setiap dialog. Jangan otomatis membuat semua tokoh memakai suara konselor yang sama; tokoh boleh menghindar, salah paham, marah, kikuk, egois, atau menyakitkan sesuai pilihan.

Bahasa Indonesia natural dengan irama lisan yang cocok untuk masing-masing tokoh. Hindari terjemahan kaku, pembuka generik berulang, metafora yang dipaksakan, jargon mesin dalam mulut NPC, dan penutup moral seragam. Jangan menyalin prosa sekarang hanya dengan sinonim; ia bahan kasar yang boleh diganti total. Pertahankan fakta yang dikunci, bukan kualitas prosa lama. Tidak ada batas kata buatan: tulis sepanjang yang dibutuhkan adegan, dengan setiap cabang mendapatkan perkembangan, reaksi, dan pendaratan yang terasa berbeda; jangan memanjangkan dengan pengulangan.

Tema gelap tetap boleh intens: kecemburuan, obsesi, penolakan, perselingkuhan emosional, ancaman, krisis keluarga, kekerasan nonseksual, trauma dan akibat sosial/hukum. Kekerasan seksual tidak ditulis grafis atau sebagai langkah menembus perlawanan; potong ke akibat. Jangan uraikan metode bunuh diri/menyakiti diri atau prosedur memfitnah/menjebak korban. Tulis niat, ketegangan, penderitaan, respons orang lain dan konsekuensinya dengan bobot penuh. Ketakutan/ketergantungan bukan cinta atau persetujuan; tidak ada ending romantis dengan pelaku Force. Adegan intim dewasa konsensual cukup tersirat tanpa detail seksual eksplisit.

Ending boleh beberapa paragraf dan sepanjang yang pantas. Wujudkan hidup sesudah peristiwa melalui detail dan perjumpaan konkret; beri akhir yang terasa khusus bagi hasil ini. Jangan sekadar mengulangi syarat katalog, memberi ceramah umum, atau mengakhiri semuanya dengan moral yang sama. Jangan mengasumsikan ending lain terpilih bersamaan kecuali syarat di atas menyebutnya.

## Teks sekarang sebagai draf, boleh dirombak seluruhnya

```text
Ogawa lolos dari akibat yang seharusnya dihadapi. Bukti tidak cukup atau tertahan, dan orang yang punya kuasa lebih suka menerima cerita yang paling sedikit mengganggu institusi. Nama Harumi justru menjadi bagian yang dipertanyakan.

Kesempatan akademiknya menyusut. Pertanyaan tentang riset berubah menjadi pertanyaan tentang sikap dan keputusan pribadinya, seolah hanya ia yang wajib menjelaskan mengapa relasi kuasa itu terjadi. Ia mulai menolak undangan sebelum harus merasakan tatapan yang sama lagi.

Kau menyaksikan dari jarak yang cukup aman untuk menyebut semuanya rumit. Harumi tidak memiliki kemewahan jarak itu. Di meja kerjanya, berkas yang tidak berhasil membuat orang percaya tersusun di samping penelitian yang kehilangan masa depan. Kekalahan dalam proses tidak membuat perbuatan Ogawa benar; hanya membuat kebenaran lebih berat ditanggung orang yang telah dilukai.
```

## Format keluaran wajib

Hanya satu blok kode python berisi assignment berikut dengan isi pengganti:

```python
    KK_END_TEXT["E-HA-08"] = """Teks ending penuh, boleh beberapa paragraf."""
```

Pertahankan empat spasi di awal assignment karena ia akan masuk ke blok init Python yang SUDAH ADA di `game/kk_ending_story.rpy`. Jangan keluarkan init/label baru, menu, efek, ekspresi interpolasi, ID lain, tiga kutip di tengah isi, atau penjelasan sebelum/sesudah kode. Tidak ada TODO, bagian disingkat, atau permintaan melanjutkan. Periksa sendiri kecocokan host, kondisi dan konsekuensi sebelum menjawab.
