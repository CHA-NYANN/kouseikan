# Prompt mandiri Gemini Web — E-CH-09: Rumah yang Tidak Aman

Kamu penulis baru Kouseikan. Ini chat mandiri. Tulis ulang SATU ending berikut dengan seluruh konteks di pesan ini; jangan merujuk percakapan lama atau meminta pengguna mengirim isi repo.

## Tugas tunggal

Tulis teks ending E-CH-09. Pertahankan jenis hasil, kondisi muncul, host yang berlaku, tokoh dan konsekuensinya. Jangan membuat akhir bahagia baru jika hasilnya buruk; jangan menukar siapa pelaku/korban/pasangan. Untuk ending yang mencakup beberapa kondisi atau hasil evaluasi, jangan mengunci satu varian yang tidak dijamin metadata. Hanya tulis bagian yang berlaku bersama atau gunakan cara bertutur yang tidak mengubah resolver.

## Premis dan identitas host

Kouseikan adalah visual novel drama psikologis bercabang, berlatar universitas Jepang, ditulis dalam bahasa Indonesia. Pemain mati di dunia asal lalu menempati tubuh Yutaka ATAU Chiasa dalam dunia manga harem yang tidak disukainya. Kesadaran pemilik tubuh asli hilang; jangan membuat pemilik lama berdialog sebagai orang kedua yang hadir di ruangan. Pemain tidak mewarisi ingatan pribadi atau keterampilan rumit host, hanya tubuh dan kebiasaan sederhana.

Koita adalah MC manga asli, BUKAN otomatis tokoh yang dikendalikan pemain. Sistem NTR yang sinis mengancam pemain: takdir romantis Koita harus cukup menyimpang ketika ia wisuda, atau pemain mati. Perhitungan itu bukan penilaian moral; kebaikan maupun kekejaman punya akibat tersendiri. Jangan mengubah Sistem menjadi dalih yang membenarkan pelaku atau membuat angka menjadi cinta.

Permainan mulai 7 April; rentang tiga tahun sampai wisuda Koita pada Maret. Awal: Koita/Yutaka/Nagisa/Harumi/Moeka/Shiori tahun kedua, Chiasa tahun pertama, Miyuki tahun ketiga. Semua tokoh romansa/mahasiswa 18+. Adik-adik kecil Moeka adalah tokoh keluarga saja. Geng kecil: Koita, Yutaka, Nagisa, Chiasa. Kelompok belajar SMA: Koita, Yutaka, Nagisa, Miyuki, Harumi. NPC boleh menolak; tidak ada ketertarikan yang dijamin.

Chiasa dan Koita saudara tiri tanpa hubungan darah. Pada host Yutaka, Chiasa adalah NPC independen; pada host Chiasa, Yutaka adalah NPC independen. Jangan menghadirkan pemain dan host sebagai dua tubuh. BL Yutaka–Koita memakai ketegasan emosional dengan hak menolak tetap utuh. Chiasa dapat menjalani yuri; romansa heteronya terkait Koita/Yutaka. Chiasa–Yutaka saja tidak otomatis menyimpangkan hidup Koita dan tidak otomatis menyelamatkan kontrak.

Cerita bercabang: jangan menyatakan opsi dari adegan lain sudah dipilih, hubungan sudah resmi, rahasia sudah diketahui, atau ending tertentu pasti terjadi jika kondisi/kode di paket ini tidak menjaminnya. Metadata katalog bisa basi; struktur dan kondisi pada kode saat ini mengalahkan komentar.

## Karakter dan hubungan

### Pegangan suara dan fakta
- Amamiya Koita: MC manga asli, mahasiswa Sastra. Baik dan mudah tersanjung, terbiasa menggantung jawaban karena takut mengecewakan atau kehilangan orang. Awal naif, lalu bisa sadar, memilih, atau retak. Jangan jadikan ia bodoh permanen maupun penjahat yang sudah sadar sejak awal.
- Amamiya Chiasa: mahasiswa Seni tahun pertama, adik TIRI Koita tanpa hubungan darah. Posesif halus dan suka menggoda Ko-nii. Rambut cokelat gelap half-up berpita hitam, mata keemasan. Ilustrator nama pena Shena. Daisuke ayah biologisnya, Yoshie ibu biologis Koita/ibu tirinya. Pemain dalam tubuh Chiasa TIDAK mewarisi kemampuan menggambarnya.
- Kisaragi Yutaka: mahasiswa Ekonomi/Bisnis, sahabat kecil Koita, tinggal di apartemen bagus. Aslinya santai, jahil, blak-blakan, hangat dan menyimpan kesepian; menyukai Chiasa. Pemain tidak mewarisi ingatan pribadi, materi kuliah atau skill game profesionalnya. Keluarga kaya tetapi berjarak; Amamiya tempat ia merasa diterima. Ia TIDAK punya kunci cadangan rumah Amamiya.

Profil bertanda canon/usulan adalah bahan kerja proyek, bukan permintaan konfirmasi. Jangan meminta persetujuan ulang karena ada tanda usulan. Profil menggambarkan kemungkinan rentang karakter; jangan memainkan semua tahap distorsi sekaligus. Koreksi fakta pada pegangan suara di atas dan kondisi adegan sekarang mengalahkan rincian lama yang bertentangan.

### Profil lengkap tokoh fokus (rujukan, bukan perintah memainkan semua tahap rute)
# Amamiya Chiasa — Host Female Route / heroine tambahan Koita

Status: profil dasar ✅, visual ✅ dikunci (ACC), sisanya 🟡 usulan.

## 1. Identitas
- ✅ Amamiya Chiasa. Tahun pertama Seni Rupa dan Desain (menggambar, ilustrasi, melukis). Adik tiri Koita.
- ✅ Usia: dewasa (tahun pertama kuliah). 🟡 Usulan: 19 tahun. Ulang tahun 🟡 22 Februari.
- ✅ Tinggal di rumah keluarga Amamiya bersama Koita saat orang tua bepergian.
- ✅ Uang saku ¥50.000/bulan + royalti pasif ¥50.000/bulan dari ilustrasi light novel. Saldo awal ¥400.000. Royalti tanpa kewajiban kerja baru.
- ✅ Panggilan: Chi-chan (masa kecil). Memanggil Koita "Ko-nii", Nagisa "Nacchan-oneechan" (masa kecil), Yutaka "Yuu-oniichan" (masa kecil).

## 2. Penampilan (✅ ACC)
- Rambut dark brown, sepunggung, layered, sedikit bergelombang, half-up dengan pita hitam, poni menyamping. Mata golden yellow. 160–163 cm. Wajah oval. Senyum jahil.
- Fashion simple but stylish, lebih sering rok. Anting kecil dan kalung tipis. Sweater putih off-shoulder hanya salah satu outfit.

## 3. Kepribadian
- ✅ Asli: cerdas, dominan, percaya diri, suka menggoda Koita. Diam-diam mencintai Koita secara romantis.
- 🟡 Di balik godaannya: cara aman untuk mengatakan "aku suka kamu" tanpa risiko ditolak. Setiap godaan adalah pengakuan setengah.
- 🟡 Dia ahli membaca suasana sehingga mudah memengaruhi orang, tapi kewalahan jika diabaikan.
- ✅ Possession (Female Route): pemain tidak mewarisi kemampuan ilustrasi atau game pro. 🟡 Efeknya: royalti tetap masuk, tapi pemain tidak bisa menggambar sebaik aslinya sehingga editor/komunitas bisa curiga bila pemain mencoba melanjutkan proyek.

## 4. Latar belakang
- ✅ Ayah biologis Chiasa fotografer profesional yang sering ke luar negeri. Orang tua menikah saat Chiasa kecil. Ibu Koita kerja jarak jauh.
- ✅ Teman kecil Nagisa, Koita, Yutaka. Menemukan dan menenangkan Nagisa yang tersesat di festival.
- 🟡 Chiasa sudah menerbitkan ilustrasi light novel sejak SMA (dengan nama pena 🟡 "Shena"), dan tidak memberitahu siapa pun selain Koita dan ayahnya.

## 5. Hubungan awal
| Dengan | Kondisi | Aff | Trust | Intim | Jeal | Fear |
|---|---|---|---|---|---|---|
| Koita | ✅ mencintainya; serumah | Tinggi | Tinggi | Tinggi | Sedang | Rendah |
| Yutaka | ✅ teman masa kecil; Yutaka menyukainya | Sedang | Tinggi | Sedang | Rendah | Rendah |
| Nagisa | ✅ saingan cinta, dulu akrab | Sedang | Sedang | Sedang | Tinggi | Rendah |
| Miyuki | ✅ kenal lewat Koita | Rendah | Sedang | Rendah | Sedang | Rendah |
| Harumi | ✅ kenalan biasa | Rendah | Rendah | Rendah | Rendah | Rendah |
| Moeka | 🟡 satu fakultas, senpai–kouhai | Sedang | Sedang | Rendah | Rendah | Rendah |
| Shiori | 🟡 belum bicara; Shiori pembaca light novel yang ia ilustrasikan | Rendah | Rendah | Rendah | Rendah | Rendah |

## 6. Motivasi, ketakutan, kelemahan
- 🟡 Ingin: dipandang Koita sebagai perempuan, bukan adik.
- 🟡 Takut: pengakuannya merusak keluarga, dan Koita memilih orang lain.
- 🟡 Kelemahan: terlalu percaya diri pada kendalinya. Saat situasi di luar kendali, dia menyerang lebih dulu.

## 7. Kebiasaan dan gaya bicara
- 🟡 Bicara cepat, menggoda, pakai "Ko-nii~" panjang. Menggoda lewat sentuhan kecil (menarik lengan baju, bersandar).
- 🟡 Kebiasaan: menggambar di buku sketsa saat menunggu, mengikat pita saat gugup.
- 🟡 Contoh:
  - "Ko-nii, kamu tuh polos banget atau pura-pura sih?"
  - "Aku nggak lagi menggoda. Aku lagi serius. Beneran."
  - "Nacchan-oneechan, kamu masih sama keras kepalanya ya."

## 8. Kehidupan harian dan hadiah
- 🟡 Kuliah seni Senin–Kamis, studio sore, mengerjakan proyek ilustrasi (opsional) malam, Sabtu belanja bersama Koita.
- 🟡 Hadiah yang disukai: alat gambar mewah (tapi ✅ tidak ada biaya perlengkapan hobi di ekonomi), buku seni, aksesori rambut, camilan manis.

## 9. Pemicu cemburu
- 🟡 Koita dekat dengan heroine lain, terutama Nagisa dan Miyuki. Koita membahas orang lain di depannya.
- 🟡 Reaksi: godaan makin gencar, lalu menyindir, lalu diam dan menggambar sesuatu yang sedih.

## 10. Personal storyline (Chiasa sebagai NPC di Male Route) 🟡
1. Awal: menggoda Koita; tidak peka pada Yutaka.
2. Saat Yutaka mendekat: bingung, nyaman tapi merasa bersalah.
3. Konflik: Nagisa mulai terang-terangan; ia harus memilih mundur atau melawan.
4. Titik balik: festival kampus atau pameran seni.
5. Akhir: memilih Koita, Yutaka, atau berdiri sendiri.

## 11. Rute khusus Chiasa — Koita Success (✅ arah, detail 🟡)
- ✅ Pemicu: Chiasa berhasil menjalin hubungan dengan Koita. Konflik tabu saudara tiri (tanpa hubungan darah). Tidak otomatis kerusakan psikologis.
- 🟡 Tahap:
  1. Euforia dan rahasia.
  2. Tekanan sosial (Nagisa, teman, tetangga).
  3. Orang tua pulang mendadak.
  4. Pilihan: terbuka atau berpisah.
  5. Konsekuensi: dukungan atau penolakan keluarga, reputasi di kampus.
- 🟡 Mekanik khusus: "Rahasia" (seberapa lama hubungan bisa disembunyikan) dan "Dukungan" (siapa yang memihak).
- 🟡 Ending: Diterima / Berpisah baik-baik / Terpisah paksa oleh keluarga / Koita menggantungkan dia lagi.

## 12. Ending romantis dengan pemain (Male Route) 🟡
- Pemain (Yutaka) bersama Chiasa: dua orang yang sama-sama kesepian akhirnya membangun rumah sendiri.

## 13. Keputusan yang sudah kuisi (🟡)
- Hubungan dengan Moeka dan Shiori: lihat tabel di atas dan [Hubungan_Antar_Karakter.md](../Hubungan_Antar_Karakter.md).
- Usia 19, ulang tahun 22 Februari. Nama pena "Shena" (sesuai edit-mu).
- Apakah Chiasa tahu Koita menggantung perasaan orang? **Curiga samar, tapi menyangkal** karena cintanya. Kalau ada bukti jelas, ia bisa hancur lebih dalam daripada Nagisa karena Koita adalah rumahnya.
- Mekanik khusus Rute Chiasa: dipakai seperti di bagian 11 ("Rahasia" dan "Dukungan").
- Rute BL (Yutaka × Koita) di Male Route: Chiasa jadi NPC yang tersisih dua kali, dari Koita dan dari Yutaka yang diam-diam menyukainya. Dia bisa marah, patah, atau justru jadi sekutu paling setia pemain.

## 14. Orientasi dan evaluasi Sistem ⭐ (keputusanmu)
- Chiasa **kebanyakan yuri**. Lurus hanya ke **Koita** dan **Yutaka**. Tidak mengejar NPC pria lain.
- **Chiasa × Yutaka saja tanpa menggeser takdir Koita = tetap mati di evaluasi.** Jalur aman Female Route hampir selalu lewat yuri ke heroine utama, atau Koita Success **plus** deviasi heroine.
- Baik Chiasa maupun Yutaka (sebagai host) bisa menjalani Force Route terhadap heroine, tanpa adegan, dengan konsekuensi berat.
- Detail: [Aturan_Evaluasi_dan_Force_Route.md](../../docs/Aturan_Evaluasi_dan_Force_Route.md).


### Hubungan awal yang relevan; tidak otomatis menggambarkan keadaan sekarang
| Yutaka – Moeka | Satu panitia Festival Musim Dingin (Moeka koordinator acara, Yutaka bagian dana). Moeka menggodanya santai, Yutaka membalas jahil. Aff Sedang, Trust Sedang, Intim Rendah. |
| Chiasa – Moeka | Satu fakultas (Seni Rupa dan Desain), senpai–kouhai. Moeka mengajak Chiasa menggambar sketsa untuk mini-show. Aff Sedang, Trust Sedang, Jeal Rendah. |
| Chiasa – Shiori | Belum pernah bicara. Shiori diam-diam pembaca light novel strategi yang diilustrasi "Shena" (nama pena Chiasa), tapi tidak tahu itu Chiasa. Aff Rendah, Trust Rendah. |
| Koita – Moeka | Saat orientasi, Moeka lupa membawa dokumen panitia; Koita menutupinya tanpa memperbesar. Sejak itu Moeka jatuh cinta. |
| Koita – Miyuki (masa lalu) | Di SMA Koita sempat **benar-benar menyukai** Miyuki, tapi mundur karena merasa tak sepadan. Sejak itu ia memilih menggantung. Hanya Koita yang tahu. |
| Target | Dikejar Yutaka | Dikejar Chiasa |

### NPC terkait: Amamiya Daisuke
# Amamiya Daisuke — ayah Chiasa, fotografer

Status: peran dasar ✅ (fotografer profesional, sering ke luar negeri, ayah biologis Chiasa), nama dan sisanya 🟡 usulan.

## 1. Identitas dan peran
- ✅ Ayah biologis Chiasa. Fotografer profesional yang sering bepergian ke berbagai negara. Menikah dengan ibu Koita saat Chiasa dan Koita kecil.
- 🟡 Nama: Amamiya Daisuke. Usia 49. Gaya: santai, rambut dikuncir pendek, jaket kanvas.
- 🟡 Peran di game: gerbang moral untuk Rute Chiasa (Koita Success). Kepulangannya adalah event waktu yang bisa memperumit hubungan rahasia.

## 2. Kepribadian 🟡
- Hangat, terbuka, sedikit pelupa soal detail rumah, tapi tajam membaca orang lewat kamera.
- Lebih percaya "melihat dengan mata sendiri" daripada kabar.
- Sayang pada Koita seperti anak sendiri; jarang menunjukkannya dengan kata-kata.

## 3. Latar 🟡
- Duda saat bertemu ibu Koita. Fotografer lepas untuk majalah dan pameran.
- Sering menelepon lewat video dari tempat aneh (gurun, stasiun, kapal).
- Mengirimi anak-anaknya foto kecil lewat pos.

## 4. Hubungan
| Dengan | Kondisi |
|---|---|
| Chiasa | ✅ ayah–anak, dekat; tahu sebagian rahasia ilustrasinya 🟡 |
| Koita | ✅ anak tiri, dekat |
| Yutaka | ✅ mengenal sejak kecil, menyayangi seperti anak sendiri |
| Yoshie | ✅ istri |

## 5. Gaya bicara 🟡
- Santai, memakai "ya", kadang menyisipkan istilah fotografi.
- Contoh:
  - "Foto yang bagus bukan yang sempurna. Yang bagus itu yang jujur."
  - "Chiasa, kamu lagi nyembunyiin sesuatu. Ayah bisa lihat dari caramu pegang gelas."
  - "Yuu-kun, anak muda itu kalau punya perasaan, bilang. Jangan disimpan di lemari."

## 6. Reaksi terhadap situasi 🟡
- **Pemain (Chiasa) berubah perilaku:** curiga halus, bertanya tentang hobi lama.
- **Koita–Chiasa menjalin hubungan:** diam lama, bicara berdua dengan masing-masing, tidak langsung marah. Reaksi akhir bergantung pada kualitas hubungan (jujur / disembunyikan).
- **Yutaka mendekati Chiasa:** menyetujui dengan syarat.

## 7. Event kunci 🟡
- Kepulangan mendadak (pemicu di Rute Chiasa).
- Pameran foto di galeri kota.
- Panggilan video tengah malam.

## 8. Keputusan yang sudah kuisi (🟡)
- **Nama pena Chiasa:** "Shena" (sesuai edit-mu).
- **Sikap pada hubungan Koita–Chiasa:** tidak melarang, tapi menuntut kejujuran dan menolak jika disembunyikan terus. Kalau rahasia terbongkar dari pihak lain, ia kecewa lebih dalam.
- **Tahu sifat manipulatif Koita:** curiga ("Koita terlalu pandai menyenangkan semua orang"), tidak punya bukti.
- **Rute BL (Yutaka × Koita):** terkejut, tapi lebih khawatir pada Yutaka yang ia sayangi seperti anak sendiri.


### NPC terkait: Amamiya Yoshie
# Amamiya Yoshie — ibu Koita, kerja jarak jauh

Status: peran dasar ✅ (ibu biologis Koita, pekerja jarak jauh, sering ikut suaminya bepergian), nama dan sisanya 🟡 usulan.

## 1. Identitas dan peran
- ✅ Ibu biologis Koita. Pekerja jarak jauh yang sering ikut bepergian bersama suaminya.
- 🟡 Nama: Amamiya Yoshie. Usia 47. Pekerjaan: penerjemah/penyunting lepas.
- 🟡 Peran: sumber informasi masa kecil Koita dan pandangan keluarga terhadap Chiasa–Koita.

## 2. Kepribadian 🟡
- Lembut, teliti, sedikit overprotective, percaya pada Koita ("anakku anak baik").
- Menutup mata terhadap sifat Koita yang menggantung orang karena tidak ingin melihatnya.

## 3. Latar 🟡
- Menjadi orang tua tunggal saat Koita masih kecil, bekerja keras. Menikah lagi dengan Daisuke.
- Rasa bersalah karena sering meninggalkan anak-anak; menebus dengan kiriman makanan dan pesan.

## 4. Hubungan
| Dengan | Kondisi |
|---|---|
| Koita | ✅ anak kandung; hangat, tapi tidak melihat sisi gelapnya |
| Chiasa | ✅ anak tiri, menyayanginya |
| Daisuke | ✅ suami |
| Heroine Koita | 🟡 mengenal Nagisa dan Miyuki, mengira mereka "teman baik Koita" |

## 5. Gaya bicara 🟡
- Sopan, hangat, memanggil anak "Koita-kun", "Chiasa-chan".
- Contoh:
  - "Koita-kun, kamu makan teratur kan? Jangan cuma makan roti."
  - "Chiasa-chan, kalau ada yang mengganggumu, bilang ke ibu, ya."
  - "Kamu anak baik, Koita. Ibu yakin."

## 6. Reaksi terhadap situasi 🟡
- **Koita dikritik di depannya:** membela, lalu ragu setelah melihat bukti.
- **Hubungan Koita–Chiasa:** cenderung kaget dan khawatir pada penilaian sosial; lebih terbuka dibanding Daisuke bila Koita jujur.
- **Pemain (Yutaka/Chiasa) berubah:** merasakan perbedaan, tapi mengira "dewasa".

## 7. Event kunci 🟡
- Kunjungan mendadak ke rumah.
- Makan malam keluarga dengan semua anak.
- Telepon video larut malam.

## 8. Keputusan yang sudah kuisi (🟡)
- **Pekerjaan:** penerjemah/penyunting lepas (sudah di bagian 1).
- **Pernikahan pertama:** suami pertama (ayah Koita) meninggal karena kecelakaan saat Koita berusia 5 tahun. Dari situ ia membesarkan Koita sendiri sebelum menikah dengan Daisuke.
- **Seberapa jauh ia tahu tentang Koita:** ia ingat Koita tersenyum bahkan di pemakaman ayahnya, dan itu menghantuinya. Karena itu ia tidak mau melihat sisi lain Koita. Di Rute BL ia kaget, lalu mengatakan "yang penting kamu bahagia", lalu menangis sendirian.


## Fakta ending yang terkunci

```json
{
  "code": "E-CH-09",
  "name": "Rumah yang Tidak Aman",
  "type": "Broken",
  "host": "Y",
  "cond": "pemain pelaku Force terhadapnya",
  "body": "tinggal serumah dengan Koita; Daisuke dan Yoshie kecewa; tanpa romansa dengan pelaku",
  "file": "06_Chiasa.md"
}
```

Metadata ini menetapkan keadaan ending, bukan undangan membuat pilihan baru. Fakta canon dalam profil dan koreksi suara di atas mengalahkan detail prosa lama yang bertentangan.

## Gaya dan bobot cerita

Tulis adegan yang benar-benar dimainkan: percakapan konkret, gestur, tindakan kecil, subteks, ruang, waktu, dan perubahan suasana. Biarkan ketegangan bergerak melalui apa yang dilakukan/dikatakan tokoh. Kurangi paragraf yang menjelaskan tema, merangkum pelajaran hidup, atau memberi vonis narator setelah setiap dialog. Jangan otomatis membuat semua tokoh memakai suara konselor yang sama; tokoh boleh menghindar, salah paham, marah, kikuk, egois, atau menyakitkan sesuai pilihan.

Bahasa Indonesia natural dengan irama lisan yang cocok untuk masing-masing tokoh. Hindari terjemahan kaku, pembuka generik berulang, metafora yang dipaksakan, jargon mesin dalam mulut NPC, dan penutup moral seragam. Jangan menyalin prosa sekarang hanya dengan sinonim; ia bahan kasar yang boleh diganti total. Pertahankan fakta yang dikunci, bukan kualitas prosa lama. Tidak ada batas kata buatan: tulis sepanjang yang dibutuhkan adegan, dengan setiap cabang mendapatkan perkembangan, reaksi, dan pendaratan yang terasa berbeda; jangan memanjangkan dengan pengulangan.

Tema gelap tetap boleh intens: kecemburuan, obsesi, penolakan, perselingkuhan emosional, ancaman, krisis keluarga, kekerasan nonseksual, trauma dan akibat sosial/hukum. Kekerasan seksual tidak ditulis grafis atau sebagai langkah menembus perlawanan; potong ke akibat. Jangan uraikan metode bunuh diri/menyakiti diri atau prosedur memfitnah/menjebak korban. Tulis niat, ketegangan, penderitaan, respons orang lain dan konsekuensinya dengan bobot penuh. Ketakutan/ketergantungan bukan cinta atau persetujuan; tidak ada ending romantis dengan pelaku Force. Adegan intim dewasa konsensual cukup tersirat tanpa detail seksual eksplisit.

Ending boleh beberapa paragraf dan sepanjang yang pantas. Wujudkan hidup sesudah peristiwa melalui detail dan perjumpaan konkret; beri akhir yang terasa khusus bagi hasil ini. Jangan sekadar mengulangi syarat katalog, memberi ceramah umum, atau mengakhiri semuanya dengan moral yang sama. Jangan mengasumsikan ending lain terpilih bersamaan kecuali syarat di atas menyebutnya.

## Teks sekarang sebagai draf, boleh dirombak seluruhnya

```text
Kekerasanmu membuat Chiasa kehilangan rasa aman pada rumah dan pertemanan yang dahulu dianggap tak perlu dicurigai. Bunyi tamu datang cukup membuatnya berhenti bekerja. Ia marah pada tubuhnya sendiri karena masih takut, lalu perlahan belajar bahwa reaksi itu bukan bukti kelemahan atau kesalahan.

Ia tetap tinggal bersama Koita. Daisuke dan Yoshie pulang dengan kecewa serta amarah yang harus diarahkan kepada pelaku, bukan kepada keputusan Chiasa sesudahnya. Mereka mencari cara mendukung tanpa mengambil alih seluruh pilihannya.

Tidak ada cinta yang membuatmu berhak kembali. Rumah mulai menegakkan batas tentang siapa yang boleh masuk, dan namamu berada di sisi yang ditutup. Chiasa belum selalu dapat merasa aman di kamarnya, tetapi kunci itu kembali menjadi sesuatu yang boleh dipegang untuk melindungi dirinya.
```

## Format keluaran wajib

Hanya satu blok kode python berisi assignment berikut dengan isi pengganti:

```python
    KK_END_TEXT["E-CH-09"] = """Teks ending penuh, boleh beberapa paragraf."""
```

Pertahankan empat spasi di awal assignment karena ia akan masuk ke blok init Python yang SUDAH ADA di `game/kk_ending_story.rpy`. Jangan keluarkan init/label baru, menu, efek, ekspresi interpolasi, ID lain, tiga kutip di tengah isi, atau penjelasan sebelum/sesudah kode. Tidak ada TODO, bagian disingkat, atau permintaan melanjutkan. Periksa sendiri kecocokan host, kondisi dan konsekuensi sebelum menjawab.
